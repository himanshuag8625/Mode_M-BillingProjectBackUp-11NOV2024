﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Mode_M_Billing.Converters
{
    public class BoolToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isActive)
            {
                return isActive ? Brushes.Green : Brushes.Red; // Green for active, Red for inactive
            }
            if (value is bool isDelete)
            {
                return isDelete ? Brushes.Green : Brushes.Red; // Green for active, Red for inactive
            }
            return Brushes.Transparent;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
