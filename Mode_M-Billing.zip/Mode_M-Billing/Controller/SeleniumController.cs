﻿using Mode_M_Billing.Models;
using Newtonsoft.Json;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System.Windows;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Chrome;
using InputSimulatorStandard;
using System.Globalization;// Make sure this is included


namespace Mode_M_Billing.Controller
{
    public class SeleniumController
    {
        private readonly string _loginDataFilePath = "LoginDetails.json";
        private IWebDriver driver;
        private WebDriverWait wait;

        // Method to initiate Selenium and navigate to the URL

        public void UserLogin(LoginDetails loginDetails)
        {
            // Start the Selenium WebDriver (EdgeDriver in this case)
            // Specify the path to the EdgeDriver
            var edgeDriverPath = @"C:\WebDrivers\Edge129";

            // Set up the EdgeDriver with the specified path
            var edgeService = EdgeDriverService.CreateDefaultService(edgeDriverPath);
            driver = new EdgeDriver(edgeService);
            //driver = new EdgeDriver();
            //driver = new ChromeDriver();
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            string fullPath = "";
            string saveDirectory = "";
            try
            {
                // Navigate to the login page
                driver.Navigate().GoToUrl("https://brokerage.suntecktts.com");

                // Input the username
                var usernameInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[1]/div/div/div/div/div/form/div[1]/input")));
                usernameInput.SendKeys(loginDetails.Username);

                // Input the password
                var passwordInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[1]/div/div/div/div/div/form/div[2]/input")));
                passwordInput.SendKeys(loginDetails.Password);

                // Click the login button
                var loginButton = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/div[1]/div/div/div/div/div/form/div[3]/input")));
                loginButton.Click();

                Thread.Sleep(2000);
                // Optional: Store customer and folder path as cookies
                //driver.Manage().Cookies.AddCookie(new Cookie("CustomerName", loginDetails.CustomerName));
                //driver.Manage().Cookies.AddCookie(new Cookie("FolderPath", loginDetails.FolderPath));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                // Optionally close the driver
                // driver.Quit(); // Uncomment this line if you want to close the browser after use
            }
        }

        //public void DownloadPdf(LoginDetails loginDetails)
        //{
        //    // Start the Selenium WebDriver (EdgeDriver in this case)
        //    //driver = new EdgeDriver();
        //    ////driver = new ChromeDriver();
        //    //wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
        //    string fullPath = "";
        //    string saveDirectory = "";
        //    try
        //    {
        //        // Hover over the finance navigation link
        //        var financeNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/header/nav/div/div/div[3]/ul/li[5]/a")));
        //        Actions actions = new Actions(driver);
        //        actions.MoveToElement(financeNavLink).Perform();

        //        // Click on the invoice queue navigation link
        //        var invoiceQueueNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/header/nav/div/div/div[3]/ul/li[5]/ul/li[6]")));
        //        invoiceQueueNavLink.Click();

        //        if (loginDetails.CustomerName.ToLower() == "yakult")
        //        {
        //            // Handling date selection logic based on the day of the week
        //            var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/span/span")));
        //            presentsFilterNavLink.Click();
        //            if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
        //            {
        //                DateTime today = DateTime.Now;
        //                DateTime lastFriday = today.AddDays(-(int)today.DayOfWeek - 2); // Last Friday
        //                DateTime lastSunday = today.AddDays(-(int)today.DayOfWeek); // Last Sunday

        //                // Open the calendar for the first date input and select last Friday
        //                var firstDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/div/div[1]/input")));
        //                firstDateInput.Click(); // Open calendar
        //                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[1]"))); // Wait for calendar to appear

        //                // Select last Friday's date
        //                var lastFridayDateXPath = $"//td[contains(@class, 'day') and text()='{lastFriday.Day}']"; // Adjust based on your calendar implementation
        //                var lastFridayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastFridayDateXPath)));
        //                lastFridayDate.Click(); // Click on the date
        //                firstDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/div/div[1]/input")));
        //                firstDateInput.Click(); // Open calendar
        //                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[1]"))); // Wait for calendar to appear
        //                lastFridayDateXPath = $"//td[contains(@class, 'day') and text()='{lastFriday.Day}']"; // Adjust based on your calendar implementation
        //                lastFridayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastFridayDateXPath)));
        //                lastFridayDate.Click(); // Click on the date

        //                // Open the calendar for the second date input and select last Sunday
        //                var secondDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/div/div[2]/input")));
        //                secondDateInput.Click(); // Open calendar
        //                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[1]"))); // Wait for calendar to appear

        //                // Select last Sunday's date
        //                var lastSundayDateXPath = $"//td[contains(@class, 'day') and text()='{lastSunday.Day}']"; // Adjust based on your calendar implementation
        //                var lastSundayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastSundayDateXPath)));
        //                lastSundayDate.Click(); // Click on the date
        //            }
        //            else
        //            {
        //                var yesterdayFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/span/div/ul[1]/li[1]/a")));
        //                yesterdayFilterNavLink.Click();
        //            }
        //            // Input customer name and preferences
        //            var customerInputElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[4]/div/div[2]/input")));
        //            customerInputElement.SendKeys(loginDetails.CustomerName.ToLower());
        //            customerInputElement.SendKeys(Keys.Enter);

        //            var preferenceInputElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[5]/div/div[2]/div/div/div[1]/input")));
        //            preferenceInputElement.SendKeys(Keys.Backspace);
        //            preferenceInputElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[5]/div/div[2]/div/div/div[3]/div[2]")));
        //            preferenceInputElement.Click();

        //            // Click search element
        //            var printStatusElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[6]/div/div[2]/div/button")));

        //            //printStatusElement.SendKeys("unprinted");
        //            printStatusElement.Click();

        //            var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div/input[1]")));
        //            searchElement.Click();
        //            try
        //            {
        //                // Check if noRecordsElement is present and visible
        //                bool isNoRecordsElementPresent = wait.Until(driver =>
        //                {
        //                    try
        //                    {
        //                        var element = driver.FindElement(By.XPath("/html/body/form/div[3]/center/h4"));
        //                        return element.Displayed; // Return true if the element is visible
        //                    }
        //                    catch (NoSuchElementException)
        //                    {
        //                        return false; // Element not found, return false
        //                    }
        //                });

        //                if (isNoRecordsElementPresent)
        //                {
        //                    var noRecordsElement = driver.FindElement(By.XPath("/html/body/form/div[3]/center/h4"));
        //                    string noRecordsMessage = noRecordsElement.Text;

        //                    // Optionally, check if the message indicates no matching records
        //                    if (noRecordsMessage.ToLower().Contains("no matching records found"))
        //                    {
        //                        // Click on the dropdown button to reveal options
        //                        printStatusElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[6]/div/div[2]/div/button")));
        //                        printStatusElement.Click();  // Click to open the dropdown

        //                        // Wait for the dropdown option "Printed" to become clickable and select it
        //                        var printStatusElement1 = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[6]/div/div[2]/div/div/ul/li[4]/a")));
        //                        printStatusElement1.Click();  // Select the "Printed" option

        //                        // Wait for the search button and click it
        //                        var searchElement1 = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div/input[1]")));
        //                        searchElement1.Click();
        //                    }
        //                }
        //                else
        //                {
        //                    Console.WriteLine("No records element not found, skipping the subsequent steps.");
        //                }
        //            }
        //            catch (WebDriverException ex)
        //            {
        //                // Handle any WebDriver exception, such as timeout or element not found
        //                Console.WriteLine("An error occurred: " + ex.Message);
        //            }

        //            var printerElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/div[2]/div/button")));

        //            // Click the final element
        //            printerElement.Click();
        //            var selectPrinterElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/div[2]/div/div/ul/li[3]/a")));

        //            // Click the final element
        //            selectPrinterElement.Click();
        //            // Click on print invoices button
        //            var printInvoicesElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/input")));
        //            printInvoicesElement.Click();

        //            Thread.Sleep(6000);
        //            wait.Until(d => d.Url.ToLower().Contains("https://brokerage.suntecktts.com/web/api/print_queue/pdf"));

        //            Actions action = new Actions(driver);
        //            Thread.Sleep(6000);
        //            action.KeyDown(Keys.Control).SendKeys("s").KeyUp(Keys.Control).Perform();
        //            Thread.Sleep(2000);

        //            //string downloadPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\Downloads\";
        //            string baseDirectory = @loginDetails.FolderPath; // You can use loginDetails.FolderPath if set
        //            string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

        //            // Combine base path and current date folder
        //            saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

        //            // Create the folder if it doesn't exist
        //            if (!Directory.Exists(saveDirectory))
        //            {
        //                Directory.CreateDirectory(saveDirectory); // Create directory with the current date
        //            }
        //            string newFileName = $"Yakult {DateTime.Now:MM-dd-yy}.pdf";
        //            fullPath = Path.Combine(saveDirectory, newFileName);
        //            Thread.Sleep(2000);
        //            // Use InputSimulator to send the filename to the Save As dialog
        //            var sim = new InputSimulator();


        //            sim.Keyboard.TextEntry(fullPath); // Type the full path
        //            sim.Keyboard.KeyPress(InputSimulatorStandard.Native.VirtualKeyCode.RETURN); // Press Enter to save

        //            Thread.Sleep(2000);
        //            // Wait for the file to download
        //            WaitForFileDownload(fullPath);

        //            // Check if the downloaded file exists
        //            if (File.Exists(fullPath))
        //            {
        //                Console.WriteLine($"File successfully saved as {newFileName} in Downloads.");
        //            }
        //            else
        //            {
        //                Console.WriteLine("Downloaded file not found.");
        //            }
        //            Thread.Sleep(2000);
        //            driver.Navigate().Back();
        //            Thread.Sleep(2000);
        //        }

        //        Thread.Sleep(2000);
        //        // Optional: Store customer and folder path as cookies
        //        //driver.Manage().Cookies.AddCookie(new Cookie("CustomerName", loginDetails.CustomerName));
        //        //driver.Manage().Cookies.AddCookie(new Cookie("FolderPath", loginDetails.FolderPath));
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Error: " + ex.Message);
        //    }
        //    finally
        //    {
        //        // Optionally close the driver
        //        // driver.Quit(); // Uncomment this line if you want to close the browser after use
        //    }
        //}


        public void DownloadPdf(LoginDetails loginDetails)
        {
            // Start the Selenium WebDriver (EdgeDriver in this case)
            // driver = new EdgeDriver();
            // driver = new ChromeDriver();
            // wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
            string fullPath = "";
            string saveDirectory = "";
            try
            {
                // Hover over the finance navigation link
                var financeNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/header/nav/div/div/div[3]/ul/li[5]/a")));
                Actions actions = new Actions(driver);
                actions.MoveToElement(financeNavLink).Perform();

                // Click on the invoice queue navigation link
                var invoiceQueueNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/header/nav/div/div/div[3]/ul/li[5]/ul/li[6]")));
                invoiceQueueNavLink.Click();

                if (loginDetails.CustomerName.ToLower() == "yakult")
                {
                    // Handling date selection logic based on the day of the week
                    var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/span/span")));
                    presentsFilterNavLink.Click();
                    if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
                    {
                        DateTime today = DateTime.Now;
                        DateTime lastFriday = today.AddDays(-(int)today.DayOfWeek - 2); // Last Friday
                        DateTime lastSunday = today.AddDays(-(int)today.DayOfWeek); // Last Sunday

                        // Open the calendar for the first date input and select last Friday
                        var firstDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/div/div[1]/input")));
                        firstDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[1]"))); // Wait for calendar to appear

                        // Select last Friday's date
                        var lastFridayDateXPath = $"//td[contains(@class, 'day') and text()='{lastFriday.Day}']"; // Adjust based on your calendar implementation
                        var lastFridayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastFridayDateXPath)));
                        lastFridayDate.Click();

                        // Open the calendar for the second date input and select last Sunday
                        var secondDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/div/div[2]/input")));
                        secondDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[1]"))); // Wait for calendar to appear

                        // Select last Sunday's date
                        var lastSundayDateXPath = $"//td[contains(@class, 'day') and text()='{lastSunday.Day}']"; // Adjust based on your calendar implementation
                        var lastSundayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastSundayDateXPath)));
                        lastSundayDate.Click();
                    }
                    else
                    {
                        var yesterdayFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/span/div/ul[1]/li[1]/a")));
                        yesterdayFilterNavLink.Click();
                    }

                    // Input customer name and preferences
                    var customerInputElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[4]/div/div[2]/input")));
                    customerInputElement.SendKeys(loginDetails.CustomerName.ToLower());
                    customerInputElement.SendKeys(Keys.Enter);

                    var preferenceInputElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[5]/div/div[2]/div/div/div[1]/input")));
                    preferenceInputElement.SendKeys(Keys.Backspace);
                    preferenceInputElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[5]/div/div[2]/div/div/div[3]/div[2]")));
                    preferenceInputElement.Click();

                    // Click search element
                    var printStatusElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[6]/div/div[2]/div/button")));
                    printStatusElement.Click();

                    var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div/input[1]")));
                    searchElement.Click();

                    // Check if noRecordsElement is present and visible
                    bool isNoRecordsElementPresent = wait.Until(driver =>
                    {
                        try
                        {
                            var element = driver.FindElement(By.XPath("/html/body/form/div[3]/center/h4"));
                            return element.Displayed;
                        }
                        catch (NoSuchElementException)
                        {
                            return false;
                        }
                    });

                    if (isNoRecordsElementPresent)
                    {
                        var noRecordsElement = driver.FindElement(By.XPath("/html/body/form/div[3]/center/h4"));
                        string noRecordsMessage = noRecordsElement.Text;

                        if (noRecordsMessage.ToLower().Contains("no matching records found"))
                        {
                            printStatusElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[6]/div/div[2]/div/button")));
                            printStatusElement.Click();

                            var printStatusElement1 = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[2]/div[2]/div/div[6]/div/div[2]/div/div/ul/li[4]/a")));
                            printStatusElement1.Click();

                            var searchElement1 = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div/input[1]")));
                            searchElement1.Click();
                        }
                    }

                    // Click the disSelectAllElement
                    //var disSelectAllElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[2]/div/div[2]/div/table/thead/tr/th[2]/input")));
                    //disSelectAllElement.Click();

                    //// Check how many <tr> are present in the tbody
                    //var rows = driver.FindElements(By.XPath("/html/body/form/div[3]/div[2]/div/div[2]/div/table/tbody/tr"));

                    //foreach (var row in rows)
                    //{
                    //    // Find the checkbox input in the first <td> of each row
                    //    var checkbox = row.FindElement(By.XPath("./td[1]/input"));
                    //    checkbox.Click(); // Click the checkbox

                    //    // Get the value of the checkbox to use as the filename
                    //    string checkBoxValue = checkbox.GetAttribute("value");

                    //    // Click the print button
                    //    var printerElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/div[2]/div/button")));
                    //    printerElement.Click();

                    //    var selectPrinterElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/div[2]/div/div/ul/li[3]/a")));
                    //    selectPrinterElement.Click();

                    //    var printInvoicesElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/input")));
                    //    printInvoicesElement.Click();

                    //    Thread.Sleep(6000);
                    //    wait.Until(d => d.Url.ToLower().Contains("https://brokerage.suntecktts.com/web/api/print_queue/pdf"));

                    //    Actions action = new Actions(driver);
                    //    Thread.Sleep(6000);
                    //    action.KeyDown(Keys.Control).SendKeys("s").KeyUp(Keys.Control).Perform();
                    //    Thread.Sleep(2000);

                    //    // Set the save path and filename
                    //    string baseDirectory = @loginDetails.FolderPath;
                    //    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                    //    saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                    //    if (!Directory.Exists(saveDirectory))
                    //    {
                    //        Directory.CreateDirectory(saveDirectory);
                    //    }

                    //    string newFileName = $"Yakult_{checkBoxValue}_{DateTime.Now:MM-dd-yy}.pdf";
                    //    fullPath = Path.Combine(saveDirectory, newFileName);

                    //    // Use InputSimulator to send the filename to the Save As dialog
                    //    var sim = new InputSimulator();
                    //    sim.Keyboard.TextEntry(fullPath);
                    //    sim.Keyboard.KeyPress(InputSimulatorStandard.Native.VirtualKeyCode.RETURN);

                    //    Thread.Sleep(2000);
                    //    WaitForFileDownload(fullPath);

                    //    if (File.Exists(fullPath))
                    //    {
                    //        Console.WriteLine($"File successfully saved as {newFileName}.");
                    //    }
                    //    else
                    //    {
                    //        Console.WriteLine("Downloaded file not found.");
                    //    }

                    //    Thread.Sleep(2000);
                    //    driver.Navigate().Back();
                    //    Thread.Sleep(2000);
                    //}

                    // Check how many <tr> elements are present in the tbody
                    var rows = driver.FindElements(By.XPath("/html/body/form/div[3]/div[2]/div/div[2]/div/table/tbody/tr"));

                    // Loop through each row
                    for (int i = 1; i <= rows.Count; i++)
                    {
                        var disSelectAllElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[2]/div/div[2]/div/table/thead/tr/th[2]/input")));
                        disSelectAllElement.Click();
                        // Dynamically construct the XPath for the checkbox based on the row index
                        string checkboxXPath = $"/html/body/form/div[3]/div[2]/div/div[2]/div/table/tbody/tr[{i}]/td[2]/input[1]";
                        
                        // Find and click the checkbox
                        var checkbox = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(checkboxXPath)));
                        checkbox.Click(); // Click the checkbox
                        
                        //if (i >= 2)
                        //{
                        //    string previousCheckboxXPath = $"/html/body/form/div[3]/div[2]/div/div[2]/div/table/tbody/tr[{i-1}]/td[1]/input";

                        //    // Find and click the checkbox
                        //    var previousCheckbox = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(previousCheckboxXPath)));
                        //    previousCheckbox.Click();
                        //}
                        // Get the value of the checkbox to use as the filename
                        string checkBoxValue = checkbox.GetAttribute("value");

                        // Click the print button
                        var printerElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/div[2]/div/button")));
                        printerElement.Click();

                        var selectPrinterElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/div[2]/div/div/ul/li[3]/a")));
                        selectPrinterElement.Click();

                        var printInvoicesElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[3]/div[1]/div/div/div[2]/div/input")));
                        printInvoicesElement.Click();

                        // Wait for the PDF to load and initiate the download
                        Thread.Sleep(6000);
                        wait.Until(d => d.Url.ToLower().Contains("https://brokerage.suntecktts.com/web/api/print_queue/pdf"));

                        // Simulate pressing Ctrl + S to save the file
                        Actions action = new Actions(driver);
                        Thread.Sleep(6000);
                        action.KeyDown(Keys.Control).SendKeys("s").KeyUp(Keys.Control).Perform();
                        Thread.Sleep(2000);

                        // Set the save path and filename
                        string baseDirectory = @loginDetails.FolderPath;
                        string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                        saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                        if (!Directory.Exists(saveDirectory))
                        {
                            Directory.CreateDirectory(saveDirectory);
                        }

                        //string newFileName = $"Yakult_{checkBoxValue}_{DateTime.Now:MM-dd-yy}.pdf";
                        string newFileName = $"{checkBoxValue}.pdf";
                        fullPath = Path.Combine(saveDirectory, newFileName);

                        // Use InputSimulator to send the filename to the Save As dialog
                        var sim = new InputSimulator();
                        sim.Keyboard.TextEntry(fullPath);
                        sim.Keyboard.KeyPress(InputSimulatorStandard.Native.VirtualKeyCode.RETURN);

                        // Wait for the file to download
                        Thread.Sleep(2000);
                        WaitForFileDownload(fullPath);

                        if (File.Exists(fullPath))
                        {
                            Console.WriteLine($"File successfully saved as {newFileName}.");
                        }
                        else
                        {
                            Console.WriteLine("Downloaded file not found.");
                        }

                        // Navigate back to the previous page
                        Thread.Sleep(2000);
                        driver.Navigate().Back();
                        Thread.Sleep(2000);
                    }
                }

                Thread.Sleep(2000);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                // Optionally close the driver
                // driver.Quit();
            }
        }


        public void InitiateBrowser(LoginDetails loginDetails)
        {
            //// Start the Selenium WebDriver (EdgeDriver in this case)
            //driver = new EdgeDriver();
            ////driver = new ChromeDriver();
            //wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
            string fullPath = "";
            string saveDirectory = "";
            try
            {
                if (loginDetails.CustomerName.ToLower() == "yakult")
                {
                    // Handling date selection logic based on the day of the week
                    //var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/span/span")));
                    //presentsFilterNavLink.Click();
                    
                    //var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div/input[1]")));
                    //searchElement.Click();
                    
                    //string downloadPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\Downloads\";
                    string baseDirectory = @loginDetails.FolderPath; // You can use loginDetails.FolderPath if set
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                    // Create the folder if it doesn't exist
                    if (!Directory.Exists(saveDirectory))
                    {
                        Directory.CreateDirectory(saveDirectory); // Create directory with the current date
                    }
                    
                    // Navigate to the specified URL
                    driver.Navigate().GoToUrl("https://brokerage.suntecktts.com/fats/loadlist.php?rptname=LOADSEARCH&sizzle=1&report_list=LOADSEARCH&my_report_custom=1&saved_report_columns=LOAD%23%2CPO%23%2CSHIP%2CSHIP+NAME%2CSHIP+CITY%2CS+ST%2CDELIV%2CCONS+NAME%2CCONS+CITY%2CC+ST%2CPALLET+TOT%2CWEIGHT%2CLH+%24CUST%2C%24CUST+LUMPER+FEES%2C%24CUST%2CINVOICED&perpage=100&search_created_table=loadsh&search_invstart=11%2F28%2F2022&search_invend=11%2F28%2F2022&search_invpreset=Yesterday&search_cust_name=Yakult&own=a&bpcs_dax_post_date=11%2F29%2F2022&sort=1-0&desc=ASC-ASC&my_report_id=69182&my_report_name=Yakult&my_report_edited=0");
                    
                    var filterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/button")));
                    filterNavLink.Click();
                    var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/span/span")));
                    presentsFilterNavLink.Click();
                    if (DateTime.Now.DayOfWeek == DayOfWeek.Monday)
                    {
                        DateTime today = DateTime.Now;
                        DateTime lastFriday = today.AddDays(-(int)today.DayOfWeek - 2); // Last Friday
                        DateTime lastSunday = today.AddDays(-(int)today.DayOfWeek); // Last Sunday

                        // Open the calendar for the first date input and select last Friday
                        var firstDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[1]/input")));
                        firstDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]"))); // Wait for calendar to appear

                        // Select last Friday's date
                        var lastFridayDateXPath = $"//td[contains(@class, 'day') and text()='{lastFriday.Day}']"; // Adjust based on your calendar implementation
                        var lastFridayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastFridayDateXPath)));
                        lastFridayDate.Click(); // Click on the date
                       
                        // Open the calendar for the second date input and select last Sunday
                        var secondDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[2]/input")));
                        secondDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]"))); // Wait for calendar to appear

                        // Select last Sunday's date
                        var lastSundayDateXPath = $"//td[contains(@class, 'day') and text()='{lastSunday.Day}']"; // Adjust based on your calendar implementation
                        var lastSundayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastSundayDateXPath)));
                        lastSundayDate.Click(); // Click on the date
                    }
                    else
                    {
                        var yesterdayFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/span/div/ul[1]/li[1]/a")));
                        yesterdayFilterNavLink.Click();
                    }

                    var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div[15]/input[1]")));
                    searchElement.Click();

                    var exportDownloadElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/div[4]/button")));
                    exportDownloadElement.Click();

                    var excelDownloadElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/div[4]/ul/li[3]")));
                    excelDownloadElement.Click();

                    // Define the base directory and current date folder
                    baseDirectory = loginDetails.FolderPath; // Assumes loginDetails.FolderPath is set
                    currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                    // Create the folder if it doesn't exist
                    if (!Directory.Exists(saveDirectory))
                    {
                        Directory.CreateDirectory(saveDirectory); // Create directory with the current date
                    }

                    // Define the new file name and full path
                    var newFileName = $"Yakult_All_Load_Search_Results {DateTime.Now:MM-dd-yy}.xlsx";
                    fullPath = Path.Combine(saveDirectory, newFileName);
                    var sim = new InputSimulator();
                    // Simulate typing the full path into the save dialog
                    
                    sim.Keyboard.TextEntry(fullPath); // Type the full path
                    sim.Keyboard.KeyPress(InputSimulatorStandard.Native.VirtualKeyCode.RETURN); // Press Enter to save

                    // Wait for the file to download
                    Thread.Sleep(2000);
                    WaitForFileDownload(fullPath); // Assuming this is a custom method that waits until the file is downloaded

                    if (File.Exists(fullPath))
                    {
                        Console.WriteLine($"File successfully saved as {newFileName} in {saveDirectory}.");
                    }
                    else
                    {
                        Console.WriteLine("File not found at the specified path. Checking default download folder...");

                        // Define the default download path
                        string defaultDownloadPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");

                        // Search for files in the default download directory containing "Yakult_All_Load_Search_Results" in their name
                        string[] filesInDefaultDownloadPath = Directory.GetFiles(defaultDownloadPath, "*All_Load_Search_Results*.xlsx");

                        if (filesInDefaultDownloadPath.Length > 0)
                        {
                            // Find the most recently modified file
                            var mostRecentFile = filesInDefaultDownloadPath
                                .Select(f => new FileInfo(f))
                                .OrderByDescending(f => f.LastWriteTime)
                                .FirstOrDefault(); // Take the most recent file

                            if (mostRecentFile != null)
                            {
                                string foundFilePath = mostRecentFile.FullName;

                                // Create the new name and path for the file
                                string renamedFileName = $"Yakult_All_Load_Search_Results {DateTime.Now:MM-dd-yy}.xlsx";
                                string renamedFilePath = Path.Combine(saveDirectory, renamedFileName);

                                try
                                {
                                    // Move and rename the file
                                    File.Move(foundFilePath, renamedFilePath);
                                    Console.WriteLine($"File successfully moved and renamed to {renamedFilePath}");
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"Error moving and renaming file: {ex.Message}");
                                }
                            }
                            else
                            {
                                Console.WriteLine("No matching 'Yakult_All_Load_Search_Results' file found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("No matching 'Yakult_All_Load_Search_Results' file found in the default download folder.");
                        }
                    }

                    Thread.Sleep(2000);
                    string projectRoot = AppDomain.CurrentDomain.BaseDirectory; // Get project root path
                    string wwwrootPath = null;
                    // Traverse upwards until you find "wwwroot" or reach the root directory
                    while (!string.IsNullOrEmpty(projectRoot))
                    {
                        // Check if "wwwroot" exists in the current directory
                        if (Directory.Exists(Path.Combine(projectRoot, "wwwroot")))
                        {
                            wwwrootPath = Path.Combine(projectRoot, "wwwroot");
                            break; // Exit loop when wwwroot is found
                        }

                        // Move one level up in the directory structure
                        projectRoot = Path.GetDirectoryName(projectRoot);
                    }

                    if (wwwrootPath != null)
                    {
                        Console.WriteLine($"Found wwwroot at: {wwwrootPath}");

                        // Now check for the "upload" folder inside wwwroot
                        string uploadPath = Path.Combine(wwwrootPath, "upload");

                        if (Directory.Exists(uploadPath))
                        {
                            Console.WriteLine($"Found upload folder at: {uploadPath}");

                            // Search for the file that contains "Yakult Default File Format" in its name
                            var files = Directory.GetFiles(uploadPath, "*Yakult Default File Format*.xlsx");
                            if (files.Any())
                            {
                                // Assuming you want the first match
                                string fileToCopy = files.First();
                                Console.WriteLine($"Found file to copy: {fileToCopy}");

                                // Define the new destination path
                                string newFilePath = Path.Combine(saveDirectory, "Yakult Default File Format.xlsx");

                                // Copy the file to the destination (overwrite if it exists)
                                File.Copy(fileToCopy, newFilePath, overwrite: true);
                                Console.WriteLine($"File successfully copied to: {newFilePath}");
                            }
                            else
                            {
                                Console.WriteLine("No file found matching 'Yakult Default File Format' in the upload folder.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Upload folder not found in wwwroot.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("wwwroot folder not found in the directory structure.");
                    }
                    // Generate the filename and wait for download
                    
                    Thread.Sleep(2000);

                    //// Search for the file containing "Yakult_All_Load_Search_Results"
                    //string[] filesInDirectory = Directory.GetFiles(saveDirectory, "*Yakult_All_Load_Search_Results*.xlsx");

                    //if (filesInDirectory.Length > 0)
                    //{
                    //    string fileToOpen = filesInDirectory[0]; // Get the first matching file
                    //    Console.WriteLine($"Opening file: {fileToOpen}");

                    //    // Open the Excel file
                    //    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    //    {
                    //        FileName = fileToOpen,
                    //        UseShellExecute = true  // Use the shell to open the file
                    //    });
                    //}
                    //else
                    //{
                    //    Console.WriteLine("No file found containing 'Yakult_All_Load_Search_Results' in its name.");
                    //}
                    
                    //// Search for the file containing "Yakult_All_Load_Search_Results"
                    //string[] filesInDirectory1 = Directory.GetFiles(saveDirectory, "*Yakult Default File Format*.xlsx");

                    //if (filesInDirectory1.Length > 0)
                    //{
                    //    string fileToOpen1 = filesInDirectory1[0]; // Get the first matching file
                    //    Console.WriteLine($"Opening file: {fileToOpen1}");

                    //    // Open the Excel file
                    //    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    //    {
                    //        FileName = fileToOpen1,
                    //        UseShellExecute = true  // Use the shell to open the file
                    //    });
                    //}
                    //else
                    //{
                    //    Console.WriteLine("No file found containing 'Yakult_All_Load_Search_Results' in its name.");
                    //}
                }
                else if (loginDetails.CustomerName.ToLower().Contains("jimmy"))
                {
                    // Handling date selection logic based on the day of the week
                    //var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/span/span")));
                    //presentsFilterNavLink.Click();

                    //var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div/input[1]")));
                    //searchElement.Click();

                    //string downloadPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\Downloads\";
                    string baseDirectory = @loginDetails.FolderPath; // You can use loginDetails.FolderPath if set
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                    // Create the folder if it doesn't exist
                    if (!Directory.Exists(saveDirectory))
                    {
                        Directory.CreateDirectory(saveDirectory); // Create directory with the current date
                    }

                    // Navigate to the specified URL
                    driver.Navigate().GoToUrl("https://brokerage.suntecktts.com/fats/loadlist.php?rptname=LOADSEARCH&sizzle=1&report_list=LOADSEARCH&my_report_custom=1&saved_report_columns=OFFICE%2CSTATUS%2CCUSTOMER+REF%23%2CLOAD%23%2CINVOICED%2CPO%23%2CITEM+DESCRIPTIONS%2CSHIP%2C%24CUST%2CMETHOD%2CCUSTOMER%2CSHIP+CITY%2CCONS+CITY%2CDELIV%2CDELIV+FINAL%2CSUM+OF+CUSTOMER+FEE+CHARGES%2CBILLING+REASON%2CBILLING+ISSUE%2CBOL%23%2CPU%23%2CCARRIER%2CFACTOR%2CLOAD+ACCT+MANAGER%2CLOAD+SALESPERSON%2CDISPATCHER%2C%24CARR%2CPRO%23%2CBILLING+DATE%2CBILLING+MESSAGE%2CCARR+INV+RECD%2CINTERCOMP+REF%23%2CBILLING+ACTIVITY%2CBILLING+WAITING+ON%2CPAYABLES+WAITING+ON%2CPAYABLES+ACTIVTY%2CLH+%24CARR%2CSUM+OF+CUSTOMER+DISCOUNTS&perpage=100&search_created_table=loadsh&search_invstart=03%2F03%2F2023&search_invend=03%2F09%2F2023&search_invpreset=Custom&search_status%5B0%5D=INVOICED&search_status%5B1%5D=POSTED&search_custm_ids=15993&own=a&bpcs_dax_post_date=03%2F10%2F2023&sort=7&desc=DESC&my_report_id=69212&my_report_name=JIMMY%27S+COOKIES&my_report_edited=0");

                    var filterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/button")));
                    filterNavLink.Click();
                    var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/span/span")));
                    presentsFilterNavLink.Click();
                    if (DateTime.Now.DayOfWeek == DayOfWeek.Friday)
                    {
                        DateTime today = DateTime.Now;
                        DateTime lastFriday = today.AddDays(-(int)today.DayOfWeek - 2); // Last Friday
                        DateTime lastThursday = today.AddDays(-1); // Last Sunday

                        // Open the calendar for the first date input and select last Friday
                        var firstDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[1]/input")));
                        firstDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]"))); // Wait for calendar to appear

                        // Select last Friday's date
                        var lastFridayDateXPath = $"//td[contains(@class, 'day') and text()='{lastFriday.Day}']"; // Adjust based on your calendar implementation
                        var lastFridayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastFridayDateXPath)));
                        lastFridayDate.Click(); // Click on the date

                        // Open the calendar for the second date input and select last Sunday
                        var secondDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[2]/input")));
                        secondDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]"))); // Wait for calendar to appear

                        // Select last Sunday's date
                        var lastSundayDateXPath = $"//td[contains(@class, 'day') and text()='{lastThursday.Day}']"; // Adjust based on your calendar implementation
                        var lastSundayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastSundayDateXPath)));
                        lastSundayDate.Click(); // Click on the date

                        var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div[15]/input[1]")));
                        searchElement.Click();

                        var exportDownloadElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/div[4]/button")));
                        exportDownloadElement.Click();

                        var excelDownloadElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/div[4]/ul/li[3]")));
                        excelDownloadElement.Click();

                        // Define the base directory and current date folder
                        baseDirectory = loginDetails.FolderPath; // Assumes loginDetails.FolderPath is set
                        currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                        // Combine base path and current date folder
                        saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                        // Create the folder if it doesn't exist
                        if (!Directory.Exists(saveDirectory))
                        {
                            Directory.CreateDirectory(saveDirectory); // Create directory with the current date
                        }

                        // Define the new file name and full path
                        var newFileName = $"Jimmys_Cookies_All_Load_Search_Results {DateTime.Now:MM-dd-yy}.xlsx";
                        fullPath = Path.Combine(saveDirectory, newFileName);
                        var sim = new InputSimulator();
                        // Simulate typing the full path into the save dialog

                        sim.Keyboard.TextEntry(fullPath); // Type the full path
                        sim.Keyboard.KeyPress(InputSimulatorStandard.Native.VirtualKeyCode.RETURN); // Press Enter to save

                        // Wait for the file to download
                        Thread.Sleep(2000);
                        WaitForFileDownload(fullPath); // Assuming this is a custom method that waits until the file is downloaded

                        if (File.Exists(fullPath))
                        {
                            Console.WriteLine($"File successfully saved as {newFileName} in {saveDirectory}.");
                        }
                        else
                        {
                            Console.WriteLine("File not found at the specified path. Checking default download folder...");

                            // Define the default download path
                            string defaultDownloadPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");

                            // Search for files in the default download directory containing "Yakult_All_Load_Search_Results" in their name
                            string[] filesInDefaultDownloadPath = Directory.GetFiles(defaultDownloadPath, "*All_Load_Search_Results*.xlsx");

                            if (filesInDefaultDownloadPath.Length > 0)
                            {
                                // Find the most recently modified file
                                var mostRecentFile = filesInDefaultDownloadPath
                                    .Select(f => new FileInfo(f))
                                    .OrderByDescending(f => f.LastWriteTime)
                                    .FirstOrDefault(); // Take the most recent file

                                if (mostRecentFile != null)
                                {
                                    string foundFilePath = mostRecentFile.FullName;

                                    // Create the new name and path for the file
                                    string renamedFileName = $"Jimmys_Cookies_All_Load_Search_Results {DateTime.Now:MM-dd-yy}.xlsx";
                                    string renamedFilePath = Path.Combine(saveDirectory, renamedFileName);

                                    try
                                    {
                                        // Move and rename the file
                                        File.Move(foundFilePath, renamedFilePath);
                                        Console.WriteLine($"File successfully moved and renamed to {renamedFilePath}");
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine($"Error moving and renaming file: {ex.Message}");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("No matching 'Yakult_All_Load_Search_Results' file found.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("No matching 'Yakult_All_Load_Search_Results' file found in the default download folder.");
                            }
                        }

                        Thread.Sleep(2000);
                        string projectRoot = AppDomain.CurrentDomain.BaseDirectory; // Get project root path
                        string wwwrootPath = null;
                        // Traverse upwards until you find "wwwroot" or reach the root directory
                        while (!string.IsNullOrEmpty(projectRoot))
                        {
                            // Check if "wwwroot" exists in the current directory
                            if (Directory.Exists(Path.Combine(projectRoot, "wwwroot")))
                            {
                                wwwrootPath = Path.Combine(projectRoot, "wwwroot");
                                break; // Exit loop when wwwroot is found
                            }

                            // Move one level up in the directory structure
                            projectRoot = Path.GetDirectoryName(projectRoot);
                        }

                        if (wwwrootPath != null)
                        {
                            Console.WriteLine($"Found wwwroot at: {wwwrootPath}");

                            // Now check for the "upload" folder inside wwwroot
                            string uploadPath = Path.Combine(wwwrootPath, "upload");

                            if (Directory.Exists(uploadPath))
                            {
                                Console.WriteLine($"Found upload folder at: {uploadPath}");

                                // Search for the file that contains "Yakult Default File Format" in its name
                                var files = Directory.GetFiles(uploadPath, "*Jimmys Cookies Default File Format*.xlsx");
                                if (files.Any())
                                {
                                    // Assuming you want the first match
                                    string fileToCopy = files.First();
                                    Console.WriteLine($"Found file to copy: {fileToCopy}");

                                    // Define the new destination path
                                    string newFilePath = Path.Combine(saveDirectory, "Jimmys Cookies Default File Format.xlsx");

                                    // Copy the file to the destination (overwrite if it exists)
                                    File.Copy(fileToCopy, newFilePath, overwrite: true);
                                    Console.WriteLine($"File successfully copied to: {newFilePath}");
                                }
                                else
                                {
                                    Console.WriteLine("No file found matching 'Jimmys Cookies Default File Format' in the upload folder.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Upload folder not found in wwwroot.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("wwwroot folder not found in the directory structure.");
                        }
                        // Generate the filename and wait for download

                        Thread.Sleep(2000);
                    }
                    
                }
                else if (loginDetails.CustomerName.ToLower().Contains("glovis"))
                {
                    // Handling date selection logic based on the day of the week
                    //var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[1]/div/div[2]/span/span")));
                    //presentsFilterNavLink.Click();

                    //var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div/input[1]")));
                    //searchElement.Click();

                    //string downloadPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\Downloads\";
                    string baseDirectory = @loginDetails.FolderPath; // You can use loginDetails.FolderPath if set
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                    // Create the folder if it doesn't exist
                    if (!Directory.Exists(saveDirectory))
                    {
                        Directory.CreateDirectory(saveDirectory); // Create directory with the current date
                    }

                    // Navigate to the specified URL
                    driver.Navigate().GoToUrl("https://brokerage.suntecktts.com/fats/loadlist.php?rptname=LOADSEARCH&sizzle=1&report_list=LOADSEARCH&my_report_custom=1&saved_report_columns=LOAD%23%2CBOL%23%2CINVOICED%2CRES%23%2C%24CUST%2CITEM+DESCRIPTIONS%2CSHIP+CITY%2CS+ST%2CCONS+CITY%2CC+ST%2CSUM+OF+CUSTOMER+FEE+CHARGES%2CPO%23%2CPRO%23%2CCUSTOMER+REF%23%2CSHIP+NAME%2CCON%23%2CEQUIP%2CMETHOD%2CTRAILER%23%2CTYPE%2CPU%23%2CREF%23%2CSOURCE+ID%2C%24CUST+ADDL+STOPS%2C%24CUST+FUEL+SURCHARGE%2C%24CUST+LUMPER+FEES%2CFS+%24CUST%2CLH+%24CUST&perpage=100&search_created_table=loadsh&search_invstart=04%2F01%2F2023&search_invend=04%2F09%2F2023&search_invpreset=Custom&search_cust_name=glovis&own=a&bpcs_dax_post_date=04%2F10%2F2023&sort=41&desc=ASC&my_report_id=69206&my_report_name=GLOVIS-1&my_report_edited=0");

                    var filterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/button")));
                    filterNavLink.Click();
                    var presentsFilterNavLink = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/span/span")));
                    presentsFilterNavLink.Click();

                    if (DateTime.Now.AddDays(-4).DayOfWeek == DayOfWeek.Friday)
                    {
                        DateTime today = DateTime.Now.AddDays(-4);
                        DateTime lastFriday = today.AddDays(-(int)today.DayOfWeek - 2); // Last Friday
                        DateTime lastThursday = today.AddDays(-1); // Last Sunday
                        var firstDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[1]/input")));
                        firstDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]")));
                        // Open the calendar for the first date input and select last Friday
                        var firstMonthYearInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[1]/table/thead/tr[1]/th[2]")));
                        firstMonthYearInput.Click();
                        var firstYearInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[2]/table/thead/tr/th[2]")));
                        firstYearInput.Click();
                        // Get the current year
                        int currentYear = DateTime.Now.Year;
                        string currentMonth = DateTime.Now.ToString("MMM", CultureInfo.InvariantCulture);

                        // Wait for the td elements containing spans to be visible
                        var yearSpans = wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(By.XPath("/html/body/div[5]/div[3]/table/tbody/tr/td/span")));

                        // Loop through each span and compare its text to the current year
                        foreach (var span in yearSpans)
                        {
                            string yearText = span.Text;
                            if (yearText.Equals(currentYear.ToString()))
                            {
                                // If the span text matches the current year, click the span and exit the loop
                                span.Click();
                                break;
                            }
                        }
                        
                        var monthSpans = wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(By.XPath("/html/body/div[5]/div[2]/table/tbody/tr/td/span")));

                        // Loop through each span and compare its text to the current year
                        foreach (var span in monthSpans)
                        {
                            string monthText = span.Text;
                            if (monthText.Equals(currentMonth.ToString()))
                            {
                                // If the span text matches the current year, click the span and exit the loop
                                span.Click();
                                break;
                            }
                        }
                        //var firstDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[1]/input")));
                        //firstDateInput.Click(); // Open calendar
                        //wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]"))); // Wait for calendar to appear

                        // Select last Friday's date
                        //var lastFridayDateXPath = $"//td[contains(@class, 'day') and text()='{lastFriday.Day}']"; // Adjust based on your calendar implementation
                        //var lastFridayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastFridayDateXPath)));
                        //lastFridayDate.Click(); // Click on the date

                        var currentMonthDaysXPath = "//tbody//tr//td[contains(@class, 'day') and not(contains(@class, 'old')) and not(contains(@class, 'new'))]";
                        var dayElements = driver.FindElements(By.XPath(currentMonthDaysXPath));

                        // Loop through all visible days in the current month and select the current day
                        //int currentDay = DateTime.Now.Day;  // Get the current day
                        foreach (var dayElement in dayElements)
                        {
                            int day = int.Parse(dayElement.Text);  // Get the day number from the text
                            if (day == lastFriday.Day)
                            {
                                // If it's the current day, click the element and break the loop
                                dayElement.Click();
                                break;
                            }
                        }

                        var secondDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[2]/input")));
                        secondDateInput.Click(); // Open calendar
                        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]")));

                        var secondMonthYearInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[1]/table/thead/tr[1]/th[2]")));
                        secondMonthYearInput.Click();
                        var secondYearInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]/div[2]/table/thead/tr/th[2]")));
                        secondYearInput.Click();
                        // Wait for the td elements containing spans to be visible
                        yearSpans = wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(By.XPath("/html/body/div[5]/div[3]/table/tbody/tr/td/span")));

                        // Loop through each span and compare its text to the current year
                        foreach (var span in yearSpans)
                        {
                            string yearText = span.Text;
                            if (yearText.Equals(currentYear.ToString()))
                            {
                                // If the span text matches the current year, click the span and exit the loop
                                span.Click();
                                break;
                            }
                        }

                        monthSpans = wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(By.XPath("/html/body/div[5]/div[2]/table/tbody/tr/td/span")));

                        // Loop through each span and compare its text to the current year
                        foreach (var span in monthSpans)
                        {
                            string monthText = span.Text;
                            if (monthText.Equals(currentMonth.ToString()))
                            {
                                // If the span text matches the current year, click the span and exit the loop
                                span.Click();
                                break;
                            }
                        }

                        // Open the calendar for the second date input and select last Sunday
                        //var secondDateInput = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/form/div[2]/div/div[2]/div[1]/div/div[5]/div/div[2]/div/div[2]/input")));
                        //secondDateInput.Click(); // Open calendar
                        //wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("/html/body/div[5]"))); // Wait for calendar to appear

                        // Select last Sunday's date
                        //var lastSundayDateXPath = $"//td[contains(@class, 'day') and text()='{lastThursday.Day}' and contains(@class, '{currentMonth}')]"; // Adjust based on your calendar implementation
                        //var lastSundayDate = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(lastSundayDateXPath)));
                        //lastSundayDate.Click(); // Click on the date

                        // Get the first day (1st) and current day (today's date)
                        //int firstDay = 1;
                        //int currentDay = DateTime.Now.Day;  // Get the current day

                        //// XPath to locate the first day of the month (1st)
                        //var firstDayXPath = "//tbody//tr//td[text()='1']";
                        //var firstDayElement = wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(firstDayXPath)));
                        //int dayone = int.Parse(firstDayElement.Text);
                        //// After finding the first day, you need to find the current day starting from the first day
                        //if (firstDayElement != null)
                        //{
                        //    // Now loop through the table cells (td) after the 1st to find the current day
                        //    var allDaysXPath = "//tbody//tr//td[contains(@class, 'day')]";  // Adjust class name if necessary
                        //    var dayElements = driver.FindElements(By.XPath(allDaysXPath));

                        //    foreach (var dayElement in dayElements)
                        //    {
                        //        int day = int.Parse(dayElement.Text);  // Get the day number
                        //        if (day == dayone)
                        //        {
                        //            int dayAfterOne = int.Parse(dayElement.Text);  // Get the day number
                        //            if (dayAfterOne == currentDay)
                        //            {
                        //                // If it's the current day, click the element and break the loop
                        //                dayElement.Click();
                        //                break;
                        //            }
                        //        }
                        //    }
                        //}

                        // XPath to locate the first day of the current month
                        currentMonthDaysXPath = "//tbody//tr//td[contains(@class, 'day') and not(contains(@class, 'old')) and not(contains(@class, 'new'))]";
                        dayElements = driver.FindElements(By.XPath(currentMonthDaysXPath));

                        // Loop through all visible days in the current month and select the current day
                        //int currentDay = DateTime.Now.Day;  // Get the current day
                        foreach (var dayElement in dayElements)
                        {
                            int day = int.Parse(dayElement.Text);  // Get the day number from the text
                            if (day == lastThursday.Day)
                            {
                                // If it's the current day, click the element and break the loop
                                dayElement.Click();
                                break;
                            }
                        }

                        var searchElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[2]/div/div[3]/div/div[15]/input[1]")));
                        searchElement.Click();

                        var exportDownloadElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/div[4]/button")));
                        exportDownloadElement.Click();

                        var excelDownloadElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("/html/body/form/div[1]/div/div/div[2]/div/div[4]/ul/li[3]")));
                        excelDownloadElement.Click();

                        // Define the base directory and current date folder
                        baseDirectory = loginDetails.FolderPath; // Assumes loginDetails.FolderPath is set
                        currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                        // Combine base path and current date folder
                        saveDirectory = Path.Combine(baseDirectory, currentDateFolder);

                        // Create the folder if it doesn't exist
                        if (!Directory.Exists(saveDirectory))
                        {
                            Directory.CreateDirectory(saveDirectory); // Create directory with the current date
                        }

                        // Define the new file name and full path
                        var newFileName = $"Glovis_All_Load_Search_Results {DateTime.Now:MM-dd-yy}.xlsx";
                        fullPath = Path.Combine(saveDirectory, newFileName);
                        var sim = new InputSimulator();
                        // Simulate typing the full path into the save dialog

                        sim.Keyboard.TextEntry(fullPath); // Type the full path
                        sim.Keyboard.KeyPress(InputSimulatorStandard.Native.VirtualKeyCode.RETURN); // Press Enter to save

                        // Wait for the file to download
                        Thread.Sleep(2000);
                        WaitForFileDownload(fullPath); // Assuming this is a custom method that waits until the file is downloaded

                        if (File.Exists(fullPath))
                        {
                            Console.WriteLine($"File successfully saved as {newFileName} in {saveDirectory}.");
                        }
                        else
                        {
                            Console.WriteLine("File not found at the specified path. Checking default download folder...");

                            // Define the default download path
                            string defaultDownloadPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");

                            // Search for files in the default download directory containing "Yakult_All_Load_Search_Results" in their name
                            string[] filesInDefaultDownloadPath = Directory.GetFiles(defaultDownloadPath, "*All_Load_Search_Results*.xlsx");

                            if (filesInDefaultDownloadPath.Length > 0)
                            {
                                // Find the most recently modified file
                                var mostRecentFile = filesInDefaultDownloadPath
                                    .Select(f => new FileInfo(f))
                                    .OrderByDescending(f => f.LastWriteTime)
                                    .FirstOrDefault(); // Take the most recent file

                                if (mostRecentFile != null)
                                {
                                    string foundFilePath = mostRecentFile.FullName;

                                    // Create the new name and path for the file
                                    string renamedFileName = $"Glovis_All_Load_Search_Results {DateTime.Now:MM-dd-yy}.xlsx";
                                    string renamedFilePath = Path.Combine(saveDirectory, renamedFileName);

                                    try
                                    {
                                        // Move and rename the file
                                        File.Move(foundFilePath, renamedFilePath);
                                        Console.WriteLine($"File successfully moved and renamed to {renamedFilePath}");
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine($"Error moving and renaming file: {ex.Message}");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("No matching 'Glovis_All_Load_Search_Results' file found.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("No matching 'Glovis_All_Load_Search_Results' file found in the default download folder.");
                            }
                        }

                        Thread.Sleep(2000);
                        string projectRoot = AppDomain.CurrentDomain.BaseDirectory; // Get project root path
                        string wwwrootPath = null;
                        // Traverse upwards until you find "wwwroot" or reach the root directory
                        while (!string.IsNullOrEmpty(projectRoot))
                        {
                            // Check if "wwwroot" exists in the current directory
                            if (Directory.Exists(Path.Combine(projectRoot, "wwwroot")))
                            {
                                wwwrootPath = Path.Combine(projectRoot, "wwwroot");
                                break; // Exit loop when wwwroot is found
                            }

                            // Move one level up in the directory structure
                            projectRoot = Path.GetDirectoryName(projectRoot);
                        }

                        if (wwwrootPath != null)
                        {
                            Console.WriteLine($"Found wwwroot at: {wwwrootPath}");

                            // Now check for the "upload" folder inside wwwroot
                            string uploadPath = Path.Combine(wwwrootPath, "upload");

                            if (Directory.Exists(uploadPath))
                            {
                                Console.WriteLine($"Found upload folder at: {uploadPath}");

                                // Search for the file that contains "Yakult Default File Format" in its name
                                var files = Directory.GetFiles(uploadPath, "*Glovis Default File Format*.xlsx");
                                if (files.Any())
                                {
                                    // Assuming you want the first match
                                    string fileToCopy = files.First();
                                    Console.WriteLine($"Found file to copy: {fileToCopy}");

                                    // Define the new destination path
                                    string newFilePath = Path.Combine(saveDirectory, "Glovis Default File Format.xlsx");

                                    // Copy the file to the destination (overwrite if it exists)
                                    File.Copy(fileToCopy, newFilePath, overwrite: true);
                                    Console.WriteLine($"File successfully copied to: {newFilePath}");
                                }
                                else
                                {
                                    Console.WriteLine("No file found matching 'Glovis Default File Format' in the upload folder.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Upload folder not found in wwwroot.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("wwwroot folder not found in the directory structure.");
                        }
                        // Generate the filename and wait for download

                        Thread.Sleep(2000);
                    }
                    
                }
                Thread.Sleep(2000);
                // Optional: Store customer and folder path as cookies
                //driver.Manage().Cookies.AddCookie(new Cookie("CustomerName", loginDetails.CustomerName));
                //driver.Manage().Cookies.AddCookie(new Cookie("FolderPath", loginDetails.FolderPath));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                // Optionally close the driver
                // driver.Quit(); // Uncomment this line if you want to close the browser after use
            }
        }

        public static void WaitForFileDownload(string filePath, int timeoutSeconds = 30)
        {
            int waitedTime = 0;
            while (!File.Exists(filePath) && waitedTime < timeoutSeconds)
            {
                Thread.Sleep(1000); // Check every second
                waitedTime++;
            }

            if (!File.Exists(filePath))
            {
                Console.WriteLine("The file was not downloaded within the timeout period.");
                //throw new FileNotFoundException("The file was not downloaded within the timeout period.");
            }
        }

        // Save login details to a JSON file
        public void SaveLoginDetails(LoginDetails loginDetails)
        {
            var jsonData = JsonConvert.SerializeObject(loginDetails, Formatting.Indented);
            File.WriteAllText(_loginDataFilePath, jsonData);
        }

        // Load login details from a JSON file
        public LoginDetails LoadLoginDetails()
        {
            if (!File.Exists(_loginDataFilePath))
                return new LoginDetails(); // Return a default empty object if file doesn't exist

            var jsonData = File.ReadAllText(_loginDataFilePath);
            return JsonConvert.DeserializeObject<LoginDetails>(jsonData);
        }
    }
}
