﻿using Mode_M_Billing.Models;
using Mode_M_Billing.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace Mode_M_Billing.Controller
{
    public class CustomerController
    {
        private readonly string _jsonFilePath;

        public CustomerController(string jsonFilePath = "CustomerData.json")
        {
            _jsonFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, jsonFilePath);
        }

        // Method to get the CustomerViewModel containing all customers
        public CustomerViewModel GetCustomerViewModel()
        {
            var customers = LoadCustomers();
            return new CustomerViewModel
            {
                Customers = customers
            };
        }

        // Load customers from the CustomerData.json file
        private List<Customer> LoadCustomers()
        {
            if (!File.Exists(_jsonFilePath))
            {
                return new List<Customer>();
            }

            var jsonData = File.ReadAllText(_jsonFilePath);
            return JsonConvert.DeserializeObject<List<Customer>>(jsonData) ?? new List<Customer>();
        }

        // Save the updated customers list back to the JSON file
        public void SaveCustomers(List<Customer> customers)
        {
            var jsonData = JsonConvert.SerializeObject(customers, Formatting.Indented);
            File.WriteAllText(_jsonFilePath, jsonData);
        }

        // Method to add a customer
        public string AddCustomer(Customer newCustomer)
        {
            List<Customer> customers = LoadCustomers();
            // Ensure the Id is set
            //if (string.IsNullOrWhiteSpace(newCustomer.Id))
            //{
            //    newCustomer.Id = Guid.NewGuid().ToString(); // Generate a new Id if not set
            //}
            customers.Add(newCustomer);
            SaveCustomers(customers);
            return "Customer added successfully!";
        }

        // Method to update an existing customer
        public string UpdateCustomer(Customer updatedCustomer)
        {
            List<Customer> customers = LoadCustomers();
            var existingCustomer = customers.Find(c => c.Id == updatedCustomer.Id);
            if (existingCustomer != null)
            {
                // Update existing customer
                existingCustomer.CustomerName = updatedCustomer.CustomerName;
                //existingCustomer.FolderPath = updatedCustomer.FolderPath;
                SaveCustomers(customers);
                return "Customer updated successfully!";
            }

            return "Customer not found!";
        }
    }
}
