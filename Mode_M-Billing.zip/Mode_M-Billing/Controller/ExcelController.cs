﻿using Mode_M_Billing.Models;
using Newtonsoft.Json;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using OfficeOpenXml.Table;

namespace Mode_M_Billing.Controller
{
    public class ExcelController
    {
        private readonly string _loginDataFilePath = "LoginDetails.json";
        private readonly string _columnMappingFilePath = "ColumnMappings.json";

        public void OpenExcel(LoginDetails loginDetails)
        {
            string fullPath = "";
            string saveDirectory = "";
            try
            {
                if (loginDetails.CustomerName.ToLower() == "yakult")
                {
                    fullPath = loginDetails.FolderPath;
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(fullPath, currentDateFolder);

                    // Open the source file first
                    string[] filesInDirectory = Directory.GetFiles(saveDirectory, "*Yakult_All_Load_Search_Results*.xlsx");

                    if (filesInDirectory.Length > 0)
                    {
                        string fileToOpen = filesInDirectory[0]; // Get the first matching file
                        Console.WriteLine($"Opening file: {fileToOpen}");

                        // Call CopyDataBetweenExcelFiles to handle copying data and saving the destination file
                        CopyDataBetweenExcelFiles(loginDetails, saveDirectory);  // Pass the saveDirectory to save the file after processing
                    }
                    else
                    {
                        Console.WriteLine("No file found containing 'Yakult_All_Load_Search_Results' in its name.");
                    }
                }
                else if (loginDetails.CustomerName.ToLower().Contains("jimmy"))
                {
                    fullPath = loginDetails.FolderPath;
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(fullPath, currentDateFolder);

                    // Open the source file first
                    string[] filesInDirectory = Directory.GetFiles(saveDirectory, "*Jimmys_Cookies_All_Load_Search_Results*.xlsx");

                    if (filesInDirectory.Length > 0)
                    {
                        string fileToOpen = filesInDirectory[0]; // Get the first matching file
                        Console.WriteLine($"Opening file: {fileToOpen}");

                        // Call CopyDataBetweenExcelFiles to handle copying data and saving the destination file
                        CopyDataBetweenExcelFiles(loginDetails, saveDirectory);  // Pass the saveDirectory to save the file after processing
                    }
                    else
                    {
                        Console.WriteLine("No file found containing 'Jimmys_Cookies_All_Load_Search_Results' in its name.");
                    }
                }
                else if (loginDetails.CustomerName.ToLower().Contains("glovis"))
                {
                    fullPath = loginDetails.FolderPath;
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(fullPath, currentDateFolder);

                    // Open the source file first
                    string[] filesInDirectory = Directory.GetFiles(saveDirectory, "*Glovis_All_Load_Search_Results*.xlsx");

                    if (filesInDirectory.Length > 0)
                    {
                        string fileToOpen = filesInDirectory[0]; // Get the first matching file
                        Console.WriteLine($"Opening file: {fileToOpen}");

                        // Call CopyDataBetweenExcelFiles to handle copying data and saving the destination file
                        CopyDataBetweenExcelFiles(loginDetails, saveDirectory);  // Pass the saveDirectory to save the file after processing
                    }
                    else
                    {
                        Console.WriteLine("No file found containing 'Glovis_All_Load_Search_Results' in its name.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        public void CopyDataBetweenExcelFiles(LoginDetails loginDetails, string saveDirectory)
        {
            try
            {
                if (loginDetails.CustomerName.ToLower() == "yakult")
                {
                    var columnMappings = LoadColumnMappings(loginDetails.CustomerName.ToLower());

                    if (columnMappings == null)
                    {
                        Console.WriteLine("Customer mapping not found in configuration.");
                        return;
                    }

                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                    // Get the current date in the desired format
                    string currentDate = DateTime.Now.ToString("MM-dd-yy");

                    string sourceFilePath = Path.Combine(loginDetails.FolderPath, currentDateFolder, columnMappings["sourceFile"]);

                    // Extract the base file name without extension and the extension itself
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(sourceFilePath);
                    string fileExtension = Path.GetExtension(sourceFilePath);

                    // Construct the new file name by inserting the formatted date before the extension
                    string newFileName1 = $"{fileNameWithoutExtension} {currentDate}{fileExtension}";

                    // Combine to get the full path with the new file name
                    string newSourceFilePath = Path.Combine(Path.GetDirectoryName(sourceFilePath), newFileName1);


                    if (!File.Exists(newSourceFilePath))
                    {
                        Console.WriteLine("Source file not found.");
                        return;
                    }

                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;  // Use NonCommercial for non-commercial use

                    // Load and manipulate Excel files using EPPlus
                    using (var sourcePackage = new ExcelPackage(new FileInfo(newSourceFilePath)))
                    {
                        var sourceWorksheet = sourcePackage.Workbook.Worksheets[0];  // Assuming first worksheet

                        // Set the destination file name as Yakult_mm-DD-yy.xlsx
                        string newFileName = $"Yakult Default File Format.xlsx";
                        string destinationFilePath = Path.Combine(saveDirectory, newFileName);

                        using (var destinationPackage = new ExcelPackage(new FileInfo(destinationFilePath)))
                        {
                            var destinationWorksheet = destinationPackage.Workbook.Worksheets[0];

                            // Get the row mappings from JSON
                            var rowMapping = columnMappings.ContainsKey("rowMapping") ? columnMappings["rowMapping"] : null;

                            int sourceStartRow = rowMapping != null && rowMapping.ContainsKey("sourceStartRow") ? rowMapping["sourceStartRow"] : 1;
                            int destinationStartRow = rowMapping != null && rowMapping.ContainsKey("destinationStartRow") ? rowMapping["destinationStartRow"] : 1;

                            // Copy the columns based on the mapping
                            foreach (var columnMapping in columnMappings["columnMapping"])
                            {
                                //string sourceColumn = columnMapping.Key;
                                //string destinationColumn = columnMapping.Value;

                                string sourceColumn = columnMapping.Path;  // Or columnMapping.Key
                                string destinationColumn = columnMapping.First.ToString();

                                CopyColumnData(sourceWorksheet, destinationWorksheet, sourceColumn, destinationColumn, sourceStartRow, destinationStartRow);
                            }

                            // Apply default values for columns N and O if they are empty
                            ApplyDefaultValues(destinationWorksheet, columnMappings, destinationStartRow);

                            // Apply formula for column M from the JSON
                            ApplyFormulas(destinationWorksheet, columnMappings, destinationStartRow);
                            // Set the new filename with the desired format: Yakult_mm-DD-yy.xlsx
                            string fileName = $"Yakult_{DateTime.Now.ToString("MM-dd-yy")}.xlsx";
                            // Combine the saveDirectory and newFileName to create the full path
                            destinationFilePath = Path.Combine(saveDirectory, fileName);
                            // Save the destination file with the new name
                            destinationPackage.SaveAs(new FileInfo(destinationFilePath));
                            Console.WriteLine($"Data copied and saved successfully as {fileName}.");
                            // Now open the saved file to apply formatting
                            using (var package = new ExcelPackage(new FileInfo(destinationFilePath)))
                            {
                                var worksheet = package.Workbook.Worksheets[0]; // Assuming first worksheet

                                // Get the last used row based on column O (which is the 15th column)
                                int lastRow = worksheet.Dimension.End.Row; // or worksheet.Cells["O:O"].End.Row

                                // Select the range from A2 to O(lastRow)
                                var dataRange = worksheet.Cells[$"A2:O{lastRow}"];

                                // Apply middle alignment (vertically) and center alignment (horizontally)
                                dataRange.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                dataRange.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

                                // Apply all borders to the selected range
                                dataRange.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                                // Save the file after applying the formatting
                                package.Save();
                                Console.WriteLine("File formatted, borders applied, and saved successfully.");
                            }
                            destinationPackage.SaveAs(new FileInfo(destinationFilePath));
                            Console.WriteLine($"Data copied and saved successfully as {fileName}.");
                        }
                    }
                }
                else if (loginDetails.CustomerName.ToLower().Contains("jimmy"))
                {
                    var columnMappings = LoadColumnMappings(loginDetails.CustomerName.ToLower());

                    if (columnMappings == null)
                    {
                        Console.WriteLine("Customer mapping not found in configuration.");
                        return;
                    }

                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                    // Get the current date in the desired format
                    string currentDate = DateTime.Now.ToString("MM-dd-yy");

                    string sourceFilePath = Path.Combine(loginDetails.FolderPath, currentDateFolder, columnMappings["sourceFile"]);

                    // Extract the base file name without extension and the extension itself
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(sourceFilePath);
                    string fileExtension = Path.GetExtension(sourceFilePath);

                    // Construct the new file name by inserting the formatted date before the extension
                    string newFileName1 = $"{fileNameWithoutExtension} {currentDate}{fileExtension}";

                    // Combine to get the full path with the new file name
                    string newSourceFilePath = Path.Combine(Path.GetDirectoryName(sourceFilePath), newFileName1);


                    if (!File.Exists(newSourceFilePath))
                    {
                        Console.WriteLine("Source file not found.");
                        return;
                    }

                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;  // Use NonCommercial for non-commercial use

                    // Load and manipulate Excel files using EPPlus
                    using (var sourcePackage = new ExcelPackage(new FileInfo(newSourceFilePath)))
                    {
                        var sourceWorksheet = sourcePackage.Workbook.Worksheets[0];  // Assuming first worksheet

                        // Set the destination file name as Yakult_mm-DD-yy.xlsx
                        string newFileName = $"Jimmys Cookies Default File Format.xlsx";
                        string destinationFilePath = Path.Combine(saveDirectory, newFileName);

                        using (var destinationPackage = new ExcelPackage(new FileInfo(destinationFilePath)))
                        {
                            var destinationWorksheet = destinationPackage.Workbook.Worksheets[0];

                            // Get the row mappings from JSON
                            var rowMapping = columnMappings.ContainsKey("rowMapping") ? columnMappings["rowMapping"] : null;

                            int sourceStartRow = rowMapping != null && rowMapping.ContainsKey("sourceStartRow") ? rowMapping["sourceStartRow"] : 1;
                            int destinationStartRow = rowMapping != null && rowMapping.ContainsKey("destinationStartRow") ? rowMapping["destinationStartRow"] : 1;

                            // Copy the columns based on the mapping
                            foreach (var columnMapping in columnMappings["columnMapping"])
                            {
                                //string sourceColumn = columnMapping.Key;
                                //string destinationColumn = columnMapping.Value;

                                string sourceColumn = columnMapping.Path;  // Or columnMapping.Key
                                string destinationColumn = columnMapping.First.ToString();

                                CopyColumnData(sourceWorksheet, destinationWorksheet, sourceColumn, destinationColumn, sourceStartRow, destinationStartRow);
                            }

                            // Apply default values for columns N and O if they are empty
                            ApplyDefaultValues(destinationWorksheet, columnMappings, destinationStartRow);

                            // Apply formula for column M from the JSON
                            ApplyFormulas(destinationWorksheet, columnMappings, destinationStartRow);
                            // Set the new filename with the desired format: Yakult_mm-DD-yy.xlsx
                            string fileName = $"JIMMY Cookies- JC{DateTime.Now.ToString("MM-dd-yy")}.xlsx";
                            // Combine the saveDirectory and newFileName to create the full path
                            destinationFilePath = Path.Combine(saveDirectory, fileName);
                            // Save the destination file with the new name
                            destinationPackage.SaveAs(new FileInfo(destinationFilePath));
                            Console.WriteLine($"Data copied and saved successfully as {fileName}.");
                            // Now open the saved file to apply formatting
                            using (var package = new ExcelPackage(new FileInfo(destinationFilePath)))
                            {
                                var worksheet = package.Workbook.Worksheets[0]; // Assuming first worksheet

                                // Get the last used row based on column O (which is the 15th column)
                                int lastRow = worksheet.Dimension.End.Row; // or worksheet.Cells["O:O"].End.Row

                                // Select the range from A2 to O(lastRow)
                                var dataRange = worksheet.Cells[$"A2:O{lastRow}"];

                                // Apply middle alignment (vertically) and center alignment (horizontally)
                                dataRange.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                dataRange.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

                                // Apply all borders to the selected range
                                dataRange.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                                // Save the file after applying the formatting
                                package.Save();
                                Console.WriteLine("File formatted, borders applied, and saved successfully.");
                            }
                        }
                    }
                }
                else if (loginDetails.CustomerName.ToLower().Contains("glovis"))
                {
                    var columnMappings = LoadColumnMappings(loginDetails.CustomerName.ToLower());

                    if (columnMappings == null)
                    {
                        Console.WriteLine("Customer mapping not found in configuration.");
                        return;
                    }

                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                    // Get the current date in the desired format
                    string currentDate = DateTime.Now.ToString("MM-dd-yy");

                    string sourceFilePath = Path.Combine(loginDetails.FolderPath, currentDateFolder, columnMappings["sourceFile"]);

                    // Extract the base file name without extension and the extension itself
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(sourceFilePath);
                    string fileExtension = Path.GetExtension(sourceFilePath);

                    // Construct the new file name by inserting the formatted date before the extension
                    string newFileName1 = $"{fileNameWithoutExtension} {currentDate}{fileExtension}";

                    // Combine to get the full path with the new file name
                    string newSourceFilePath = Path.Combine(Path.GetDirectoryName(sourceFilePath), newFileName1);


                    if (!File.Exists(newSourceFilePath))
                    {
                        Console.WriteLine("Source file not found.");
                        return;
                    }

                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;  // Use NonCommercial for non-commercial use

                    // Load and manipulate Excel files using EPPlus
                    using (var sourcePackage = new ExcelPackage(new FileInfo(newSourceFilePath)))
                    {
                        var sourceWorksheet = sourcePackage.Workbook.Worksheets[0];  // Assuming first worksheet

                        // Set the destination file name as Yakult_mm-DD-yy.xlsx
                        string newFileName = $"Glovis Default File Format.xlsx";
                        string destinationFilePath = Path.Combine(saveDirectory, newFileName);

                        using (var destinationPackage = new ExcelPackage(new FileInfo(destinationFilePath)))
                        {
                            var destinationWorksheet = destinationPackage.Workbook.Worksheets[0];

                            // Get the row mappings from JSON
                            var rowMapping = columnMappings.ContainsKey("rowMapping") ? columnMappings["rowMapping"] : null;

                            int sourceStartRow = rowMapping != null && rowMapping.ContainsKey("sourceStartRow") ? rowMapping["sourceStartRow"] : 1;
                            int destinationStartRow = rowMapping != null && rowMapping.ContainsKey("destinationStartRow") ? rowMapping["destinationStartRow"] : 1;

                            // Copy the columns based on the mapping
                            foreach (var columnMapping in columnMappings["columnMapping"])
                            {
                                //string sourceColumn = columnMapping.Key;
                                //string destinationColumn = columnMapping.Value;

                                string sourceColumn = columnMapping.Path;  // Or columnMapping.Key
                                string destinationColumn = columnMapping.First.ToString();

                                CopyColumnData(sourceWorksheet, destinationWorksheet, sourceColumn, destinationColumn, sourceStartRow, destinationStartRow);
                            }

                            // Apply default values for columns N and O if they are empty
                            ApplyDefaultValues(sourceWorksheet, destinationWorksheet, columnMappings, destinationStartRow, sourceStartRow);
                            CopyDestinationValues(sourceWorksheet, destinationWorksheet, columnMappings, destinationStartRow, sourceStartRow);

                            //int lastRow = sourceWorksheet.Dimension.End.Row;

                            //// Apply table formatting from row 2 to lastRow using TableStyles.Medium25
                            //var dataRange = destinationWorksheet.Cells[$"A2:AJ{lastRow}"];
                            //var table = destinationWorksheet.Tables.Add(dataRange, "DataTable");

                            //// Apply table style (Medium25) to the rows
                            //table.TableStyle = TableStyles.Medium25;

                            //dataRange.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            //dataRange.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

                            //dataRange.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            //dataRange.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            //dataRange.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            //dataRange.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                            //DateTime today = DateTime.Now.AddDays(-4);
                            //DateTime lastFriday = today.AddDays(-(int)today.DayOfWeek - 2); // Last Friday
                            //DateTime lastThursday = today.AddDays(-1);

                            //// Apply formula for column M from the JSON
                            //ApplyFormulas(destinationWorksheet, columnMappings, destinationStartRow);
                            //// Set the new filename with the desired format: Yakult_mm-DD-yy.xlsx
                            //string fileName = $"{lastFriday.ToString("yyyyMMdd")}_{lastThursday.ToString("yyyyMMdd")} GLOVIS BILLING SUMMARY.xlsx";
                            //// Combine the saveDirectory and newFileName to create the full path
                            //destinationFilePath = Path.Combine(saveDirectory, fileName);
                            //// Save the destination file with the new name
                            //destinationPackage.SaveAs(new FileInfo(destinationFilePath));
                            //Console.WriteLine($"Data copied and saved successfully as {fileName}.");
                            //// Now open the saved file to apply formatting
                            //using (var package = new ExcelPackage(new FileInfo(destinationFilePath)))
                            //{
                            //    var worksheet = package.Workbook.Worksheets[0]; // Assuming first worksheet

                            //    // Get the last used row based on column O (which is the 15th column)
                            //    //lastRow = worksheet.Dimension.End.Row; // or worksheet.Cells["O:O"].End.Row

                            //    // Select the range from A2 to O(lastRow)
                            //    dataRange = worksheet.Cells[$"A2:AJ{lastRow}"];

                            //    // Apply middle alignment (vertically) and center alignment (horizontally)
                            //    dataRange.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            //    dataRange.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

                            //    // Apply all borders to the selected range
                            //    dataRange.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            //    dataRange.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            //    dataRange.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            //    dataRange.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                            //    // Save the file after applying the formatting
                            //    package.Save();
                            //    Console.WriteLine("File formatted, borders applied, and saved successfully.");
                            //}

                            int lastRow = sourceWorksheet.Dimension.End.Row;

                            // Define the range for the data (from A2 to AJ[lastRow])
                            var dataRange = destinationWorksheet.Cells[$"A2:AJ{lastRow}"];

                            // Apply middle alignment (vertically) and center alignment (horizontally)
                            dataRange.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            dataRange.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

                            // Apply borders to the entire range
                            dataRange.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            dataRange.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            dataRange.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            dataRange.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                            // Apply the background fill color (similar to Medium25 styling) for alternate rows
                            for (int row = 2; row <= lastRow; row++)
                            {
                                var rowRange = destinationWorksheet.Cells[$"A{row}:AJ{row}"];

                                // Apply background color based on row number (alternating rows for table effect)
                                if (row % 2 == 0)
                                {
                                    rowRange.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                                    rowRange.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.FromArgb(191, 191, 191)); // Light gray for even rows
                                }
                                else
                                {
                                    rowRange.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                                    rowRange.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.White); // White for odd rows
                                }
                            }

                            // Save the file
                            DateTime today = DateTime.Now;
                            DateTime lastFriday = today.AddDays(-(int)today.DayOfWeek - 2); // Last Friday
                            DateTime lastThursday = today.AddDays(-1);

                            // Apply formula for column M from the JSON (assumed to be handled by ApplyFormulas method)
                            ApplyFormulas(destinationWorksheet, columnMappings, destinationStartRow);

                            // Set the new filename with the desired format
                            string fileName = $"{lastFriday:yyyyMMdd}_{lastThursday:yyyyMMdd} GLOVIS BILLING SUMMARY.xlsx";

                            // Combine the saveDirectory and newFileName to create the full path
                            destinationFilePath = Path.Combine(saveDirectory, fileName);

                            // Save the destination file with the new name
                            //destinationPackage.SaveAs(new FileInfo(destinationFilePath));
                            //Console.WriteLine($"Data copied and saved successfully as {fileName}.");

                            try
                            {
                                destinationPackage.SaveAs(new FileInfo(destinationFilePath));
                                Console.WriteLine($"Data copied and saved successfully as {fileName}.");
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Error saving file: {ex.Message}");
                                return; // Early exit if there's an error
                            }

                            // Now open the saved file to apply additional formatting
                            using (var package = new ExcelPackage(new FileInfo(destinationFilePath)))
                            {
                                var worksheet = package.Workbook.Worksheets[0]; // Assuming first worksheet

                                // Get the last used row based on column O (which is the 15th column)
                                lastRow = worksheet.Dimension.End.Row;

                                // Select the range from A2 to AJ[lastRow]
                                dataRange = worksheet.Cells[$"A2:AJ{lastRow}"];

                                // Apply middle alignment (vertically) and center alignment (horizontally)
                                dataRange.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                dataRange.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

                                // Apply all borders to the selected range
                                dataRange.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                dataRange.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

                                // Save the file after applying the formatting
                                package.Save();
                                Console.WriteLine("File formatted, borders applied, and saved successfully.");
                            }

                        }
                    }
                }
                // Load column mappings from JSON

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private Dictionary<string, dynamic> LoadColumnMappings(string customerName)
        {
            try
            {
                string projectRoot = AppDomain.CurrentDomain.BaseDirectory; // Get project root path
                string columnMappingFilePath = null;
                string fileName = "ColumnMappings.json"; // The file you're looking for

                // Traverse upwards until you find "ColumnMappings.json" or reach the root directory
                while (!string.IsNullOrEmpty(projectRoot))
                {
                    // Construct the potential path to "ColumnMappings.json"
                    string potentialFilePath = Path.Combine(projectRoot, fileName);

                    // Check if "ColumnMappings.json" exists in the current directory
                    if (File.Exists(potentialFilePath))
                    {
                        columnMappingFilePath = potentialFilePath;
                        break; // Exit loop when the file is found
                    }

                    // Move one level up in the directory structure
                    projectRoot = Path.GetDirectoryName(projectRoot);
                }

                // If the file was found, read and deserialize the JSON content
                if (!string.IsNullOrEmpty(columnMappingFilePath))
                {
                    var jsonContent = File.ReadAllText(columnMappingFilePath);
                    var mappings = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, dynamic>>>(jsonContent);

                    // Return the mapping for the specific customer
                    return mappings.ContainsKey(customerName) ? mappings[customerName] : null;
                }
                else
                {
                    Console.WriteLine("ColumnMappings.json not found.");
                    return null; // Handle the case where the file wasn't found
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading column mappings: {ex.Message}");
                return null;
            }
        }

        private void CopyColumnData(ExcelWorksheet sourceSheet, ExcelWorksheet destinationSheet, string sourceColumn, string destinationColumn, int sourceStartRow, int destinationStartRow)
        {
            int rowCount = sourceSheet.Dimension.Rows;  // Get the number of rows used in the source file

            // Copy each cell value from source to destination, adjusting for the starting rows
            for (int row = sourceStartRow; row <= rowCount; row++)
            {
                int destinationRow = destinationStartRow + (row - sourceStartRow);  // Calculate the corresponding destination row
                destinationSheet.Cells[destinationRow, destinationSheet.Cells[destinationColumn + destinationRow].Start.Column].Value = sourceSheet.Cells[row, sourceSheet.Cells[sourceColumn + row].Start.Column].Value;
            }
        }

        private void ApplyDefaultValues(ExcelWorksheet destinationSheet, Dictionary<string, dynamic> columnMappings, int destinationStartRow)
        {
            if (columnMappings.ContainsKey("defaultValues"))
            {
                var defaultValues = columnMappings["defaultValues"];

                foreach (var col in defaultValues)
                {
                    //string column = col.Key;
                    //string defaultValue = col.Value;
                    string column = col.Path;  // Or columnMapping.Key
                    string defaultValue = col.Value;
                    int rowCount = destinationSheet.Dimension.Rows;

                    // Iterate through the column, if any cell is empty, set default value
                    for (int row = destinationStartRow; row <= rowCount; row++)
                    {
                        var cell = destinationSheet.Cells[row, destinationSheet.Cells[column + row].Start.Column];
                        if (cell.Value == null || string.IsNullOrWhiteSpace(cell.Text))
                        {
                            cell.Value = defaultValue;
                        }
                    }
                }
            }
        }
        private void ApplyDefaultValues(ExcelWorksheet sourceSheet, ExcelWorksheet destinationSheet, Dictionary<string, dynamic> columnMappings, int destinationStartRow, int sourceStartRow)
        {
            if (columnMappings.ContainsKey("defaultValues"))
            {
                var defaultValues = columnMappings["defaultValues"];

                foreach (var col in defaultValues)
                {
                    //string column = col.Key;
                    //string defaultValue = col.Value;
                    string column = col.Path;  // Or columnMapping.Key
                    string defaultValue = col.Value;
                    int rowCount = sourceSheet.Dimension.Rows;

                    // Iterate through the column, if any cell is empty, set default value
                    for (int row = destinationStartRow; row <= rowCount-1; row++)
                    {
                        var cell = destinationSheet.Cells[row, destinationSheet.Cells[column + row].Start.Column];
                        if (cell.Value == null || string.IsNullOrWhiteSpace(cell.Text))
                        {
                            cell.Value = defaultValue;
                        }
                    }
                }
            }
        }

        private void ApplyFormulas(ExcelWorksheet destinationSheet, Dictionary<string, dynamic> columnMappings, int destinationStartRow)
        {
            if (columnMappings.ContainsKey("formulas"))
            {
                var formulas = columnMappings["formulas"];

                foreach (var formula in formulas)
                {
                    string targetColumn = formula.Path;
                    string formulaExpression = formula.Value;

                    int rowCount = destinationSheet.Dimension.Rows;

                    for (int row = destinationStartRow; row <= rowCount; row++)
                    {
                        // Apply the formula (e.g., O-N -> "=O1-N1")
                        destinationSheet.Cells[row, destinationSheet.Cells[targetColumn + row].Start.Column].Formula = formulaExpression.Replace("O", $"O{row}").Replace("N", $"N{row}");
                    }
                }

                // Calculate formulas in the destination sheet
                destinationSheet.Calculate();
            }
        }

        // Function to process the saved Excel file and merge PDFs
        public void ProcessExcelFile(LoginDetails loginDetails)
        {
            string fullPath = "";
            string saveDirectory = "";
            try
            {
                if (loginDetails.CustomerName.ToLower() == "yakult")
                {
                    fullPath = loginDetails.FolderPath;
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                    string currentDate = DateTime.Now.ToString("MM-dd-yy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(fullPath, currentDateFolder);

                    string fileName = $"Yakult_{currentDate}.xlsx";
                    string filePath = Path.Combine(saveDirectory, fileName);

                    if (!File.Exists(filePath))
                    {
                        Console.WriteLine($"Excel file {fileName} not found.");
                        return;
                    }

                    // Read the saved Excel file and extract column A values
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    List<string> columnAValues = new List<string>();

                    using (var package = new ExcelPackage(new FileInfo(filePath)))
                    {
                        var worksheet = package.Workbook.Worksheets[0]; // Assuming first worksheet

                        int rowCount = worksheet.Dimension.Rows;  // Get the number of rows in the worksheet

                        // Assuming that destinationStartRow is stored in your JSON configuration or fixed
                        int destinationStartRow = 3;  // Assuming row 2, you can adjust this based on your data

                        for (int row = destinationStartRow; row <= rowCount; row++)
                        {
                            var cellValue = worksheet.Cells[row, 1].Text;  // Column A is the first column (index 1)
                            if (!string.IsNullOrEmpty(cellValue))
                            {
                                columnAValues.Add(cellValue);
                            }
                        }
                    }

                    // After extracting column A values, merge PDFs based on the values in the list
                    MergePdfs(columnAValues, saveDirectory, fullPath, filePath, loginDetails);
                }
                else if (loginDetails.CustomerName.ToLower().Contains("jimmy"))
                {
                    fullPath = loginDetails.FolderPath;
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                    string currentDate = DateTime.Now.ToString("MM-dd-yy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(fullPath, currentDateFolder);

                    string fileName = $"Jimmys_Cookies_{currentDate}.xlsx";
                    string filePath = Path.Combine(saveDirectory, fileName);

                    if (!File.Exists(filePath))
                    {
                        Console.WriteLine($"Excel file {fileName} not found.");
                        return;
                    }

                    // Read the saved Excel file and extract column A values
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    List<string> columnAValues = new List<string>();

                    using (var package = new ExcelPackage(new FileInfo(filePath)))
                    {
                        var worksheet = package.Workbook.Worksheets[0]; // Assuming first worksheet

                        int rowCount = worksheet.Dimension.Rows;  // Get the number of rows in the worksheet

                        // Assuming that destinationStartRow is stored in your JSON configuration or fixed
                        int destinationStartRow = 3;  // Assuming row 2, you can adjust this based on your data

                        for (int row = destinationStartRow; row <= rowCount; row++)
                        {
                            var cellValue = worksheet.Cells[row, 1].Text;  // Column A is the first column (index 1)
                            if (!string.IsNullOrEmpty(cellValue))
                            {
                                columnAValues.Add(cellValue);
                            }
                        }
                    }

                    // After extracting column A values, merge PDFs based on the values in the list
                    MergePdfs(columnAValues, saveDirectory, fullPath, filePath, loginDetails);

                }
                else if (loginDetails.CustomerName.ToLower().Contains("glovis"))
                {
                    fullPath = loginDetails.FolderPath;
                    string currentDateFolder = DateTime.Now.ToString("dd MMM yyyy");
                    string currentDate = DateTime.Now.ToString("MM-dd-yy");

                    // Combine base path and current date folder
                    saveDirectory = Path.Combine(fullPath, currentDateFolder);

                    string fileName = $"Glovis_{currentDate}.xlsx";
                    string filePath = Path.Combine(saveDirectory, fileName);

                    if (!File.Exists(filePath))
                    {
                        Console.WriteLine($"Excel file {fileName} not found.");
                        return;
                    }

                    // Read the saved Excel file and extract column A values
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                    List<string> columnAValues = new List<string>();

                    using (var package = new ExcelPackage(new FileInfo(filePath)))
                    {
                        var worksheet = package.Workbook.Worksheets[0]; // Assuming first worksheet

                        int rowCount = worksheet.Dimension.Rows;  // Get the number of rows in the worksheet

                        // Assuming that destinationStartRow is stored in your JSON configuration or fixed
                        int destinationStartRow = 3;  // Assuming row 2, you can adjust this based on your data

                        for (int row = destinationStartRow; row <= rowCount; row++)
                        {
                            var cellValue = worksheet.Cells[row, 1].Text;  // Column A is the first column (index 1)
                            if (!string.IsNullOrEmpty(cellValue))
                            {
                                columnAValues.Add(cellValue);
                            }
                        }
                    }

                    // After extracting column A values, merge PDFs based on the values in the list
                    MergePdfs(columnAValues, saveDirectory, fullPath, filePath, loginDetails);

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing Excel file: {ex.Message}");
            }
        }

        // Function to merge PDFs based on the values in the list
        public void MergePdfs(List<string> columnAValues, string pdfDirectory, string fullPath, string filePath, LoginDetails loginDetails)
        {
            try
            {
                if (loginDetails.CustomerName.ToLower() == "yakult")
                {
                    string mergedPdfPath = Path.Combine(pdfDirectory, $"Yakult_{DateTime.Now:MM-dd-yy}.pdf");

                    using (PdfDocument mergedPdf = new PdfDocument())
                    {
                        foreach (var value in columnAValues)
                        {
                            // Construct the full path to the PDF using the value from column A
                            string pdfFileName = $"{value}.pdf";  // Assuming the PDF file is named after the value in column A
                            string pdfFilePath = Path.Combine(pdfDirectory, pdfFileName);

                            if (File.Exists(pdfFilePath))
                            {
                                // Open the PDF and append it to the merged PDF
                                using (PdfDocument inputPdf = PdfReader.Open(pdfFilePath, PdfDocumentOpenMode.Import))
                                {
                                    // Append all pages from the current PDF
                                    for (int i = 0; i < inputPdf.PageCount; i++)
                                    {
                                        mergedPdf.AddPage(inputPdf.Pages[i]);
                                    }
                                }
                                Console.WriteLine($"Merged PDF: {pdfFileName}");
                            }
                            else
                            {
                                Console.WriteLine($"PDF not found: {pdfFileName}");
                            }
                        }

                        // Save the merged PDF to the desired location
                        mergedPdf.Save(mergedPdfPath);
                        Console.WriteLine($"Merged PDF saved successfully at {mergedPdfPath}");
                    }
                }
                else if (loginDetails.CustomerName.ToLower().Contains("jimmy"))
                {
                    string mergedPdfPath = Path.Combine(pdfDirectory, $"Jimmys_Cookies_{DateTime.Now:MM-dd-yy}.pdf");

                    using (PdfDocument mergedPdf = new PdfDocument())
                    {
                        foreach (var value in columnAValues)
                        {
                            // Construct the full path to the PDF using the value from column A
                            string pdfFileName = $"{value}.pdf";  // Assuming the PDF file is named after the value in column A
                            string pdfFilePath = Path.Combine(pdfDirectory, pdfFileName);

                            if (File.Exists(pdfFilePath))
                            {
                                // Open the PDF and append it to the merged PDF
                                using (PdfDocument inputPdf = PdfReader.Open(pdfFilePath, PdfDocumentOpenMode.Import))
                                {
                                    // Append all pages from the current PDF
                                    for (int i = 0; i < inputPdf.PageCount; i++)
                                    {
                                        mergedPdf.AddPage(inputPdf.Pages[i]);
                                    }
                                }
                                Console.WriteLine($"Merged PDF: {pdfFileName}");
                            }
                            else
                            {
                                Console.WriteLine($"PDF not found: {pdfFileName}");
                            }
                        }

                        // Save the merged PDF to the desired location
                        mergedPdf.Save(mergedPdfPath);
                        Console.WriteLine($"Merged PDF saved successfully at {mergedPdfPath}");
                    }
                }
                else if (loginDetails.CustomerName.ToLower().Contains("glovis"))
                {
                    string mergedPdfPath = Path.Combine(pdfDirectory, $"Glovis_{DateTime.Now:MM-dd-yy}.pdf");

                    using (PdfDocument mergedPdf = new PdfDocument())
                    {
                        foreach (var value in columnAValues)
                        {
                            // Construct the full path to the PDF using the value from column A
                            string pdfFileName = $"{value}.pdf";  // Assuming the PDF file is named after the value in column A
                            string pdfFilePath = Path.Combine(pdfDirectory, pdfFileName);

                            if (File.Exists(pdfFilePath))
                            {
                                // Open the PDF and append it to the merged PDF
                                using (PdfDocument inputPdf = PdfReader.Open(pdfFilePath, PdfDocumentOpenMode.Import))
                                {
                                    // Append all pages from the current PDF
                                    for (int i = 0; i < inputPdf.PageCount; i++)
                                    {
                                        mergedPdf.AddPage(inputPdf.Pages[i]);
                                    }
                                }
                                Console.WriteLine($"Merged PDF: {pdfFileName}");
                            }
                            else
                            {
                                Console.WriteLine($"PDF not found: {pdfFileName}");
                            }
                        }

                        // Save the merged PDF to the desired location
                        mergedPdf.Save(mergedPdfPath);
                        Console.WriteLine($"Merged PDF saved successfully at {mergedPdfPath}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error merging PDFs: {ex.Message}");
            }
        }

        //private void CopyDestinationValues(ExcelWorksheet sourceSheet, ExcelWorksheet destinationSheet, Dictionary<string, dynamic> columnMappings, int destinationStartRow, int sourceStartRow)
        //{
        //    if (columnMappings.ContainsKey("destinationCopyColumns"))
        //    {
        //        var defaultValues = columnMappings["destinationCopyColumns"];

        //        foreach (var col in defaultValues)
        //        {
        //            //string column = col.Key;
        //            //string defaultValue = col.Value;
        //            string column = col.Path;  // Or columnMapping.Key
        //            string defaultValue = col.Value;
        //            int rowCount = sourceSheet.Dimension.Rows;

        //            // Iterate through the column, if any cell is empty, set default value
        //            for (int row = destinationStartRow; row <= rowCount; row++)
        //            {
        //                var cell = destinationSheet.Cells[row, destinationSheet.Cells[column + row].Start.Column];
        //                if (cell.Value == null || string.IsNullOrWhiteSpace(cell.Text))
        //                {
        //                    cell.Value = defaultValue;
        //                }
        //            }
        //        }
        //    }
        //}

        private void CopyDestinationValues(ExcelWorksheet sourceSheet, ExcelWorksheet destinationSheet, Dictionary<string, dynamic> columnMappings, int destinationStartRow, int sourceStartRow)
        {
            // Check if destinationCopyColumns is defined in the mappings
            if (columnMappings.ContainsKey("destinationCopyColumns"))
            {
                var destinationCopyColumns = columnMappings["destinationCopyColumns"];

                foreach (var col in destinationCopyColumns)
                {
                    string sourceColumn = col.Path;  // Source column from which to copy (e.g., "G")
                    string destinationColumn = col.Value;  // Destination column (e.g., "S")

                    // Get the index of the source and destination columns
                    int sourceColumnIndex = GetColumnIndex(sourceColumn);
                    int destinationColumnIndex = GetColumnIndex(destinationColumn);
                    int rowCount = sourceSheet.Dimension.Rows;

                    // Iterate through the rows in the destination sheet
                    for (int row = destinationStartRow; row <= rowCount; row++)
                    {
                        var sourceCell = destinationSheet.Cells[row, sourceColumnIndex];
                        var destinationCell = destinationSheet.Cells[row, destinationColumnIndex];

                        // If the source cell has a value, copy it to the destination cell
                        if (sourceCell.Value != null)
                        {
                            destinationCell.Value = sourceCell.Value;
                        }
                    }
                }
            }
        }

        // Helper method to convert column letters to their index
        private int GetColumnIndex(string columnKey)
        {
            if (!string.IsNullOrEmpty(columnKey))
            {
                // Convert the column letter to an index (A=1, B=2, ..., Z=26)
                return (int)(char.ToUpper(columnKey[0]) - 'A' + 1); // Assuming columnKey is a single letter
            }
            throw new Exception($"Invalid column key: {columnKey}");
        }

    }
}
