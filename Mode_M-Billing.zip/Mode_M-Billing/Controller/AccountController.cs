﻿using Mode_M_Billing.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Mode_M_Billing.Controller
{
    public class AccountController
    {
        private readonly string _jsonFilePath;

        public AccountController(string jsonFilePath)
        {
            _jsonFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, jsonFilePath);
        }

        // Register new user
        public string RegisterUser(string firstName, string lastName, string userName, string email, string wnsId, string password, string confirmPassword)
        {
            if (password != confirmPassword)
                return "Passwords do not match!";

            List<User> users = LoadUsers();

            // Check if username, email, or WnsId already exists
            if (users.Any(u => u.UserName == userName || u.Email == email || u.WnsId == wnsId))
                return "Username, Email, or WnsId already exists!";

            var newUser = new User
            {
                FirstName = firstName,
                LastName = lastName,
                UserName = userName,
                Email = email,
                WnsId = wnsId,
                Password = EncryptPassword(password),  // Encrypt the password
                ConfirmPassword = EncryptPassword(confirmPassword)  // Encrypt confirm password
            };

            users.Add(newUser);
            SaveUsers(users);

            return "User registered successfully!";
        }

        // Login with username or email or WnsId and password
        public string LoginUser(string identifier, string password)
        {
            List<User> users = LoadUsers(); // Assume this method loads users from some data source
            string encryptedPassword = EncryptPassword(password);  // Encrypt entered password

            // Find user by either username, email, or WnsId and match with encrypted password
            var user = users.FirstOrDefault(u =>
                (u.UserName == identifier || u.Email == identifier || u.WnsId == identifier) && u.Password == encryptedPassword);

            if (user != null)
            {
                // Check if the user is active and not deleted
                if (!user.IsActive)
                {
                    return "User is not active.";
                }

                if (user.IsDelete)
                {
                    return "User has been deleted.";
                }

                return "Login successful!";
            }

            return "Invalid username, email, WnsId, or password!";
        }

        // Encrypt password using SHA256
        public static string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // Save users to the JSON file
        private void SaveUsers(List<User> users)
        {
            string jsonData = JsonConvert.SerializeObject(users, Formatting.Indented);
            File.WriteAllText(_jsonFilePath, jsonData);
        }

        // Load users from the JSON file
        private List<User> LoadUsers()
        {
            if (!File.Exists(_jsonFilePath))
            {
                return new List<User>();
            }

            string jsonData = File.ReadAllText(_jsonFilePath);
            return JsonConvert.DeserializeObject<List<User>>(jsonData) ?? new List<User>();
        }
    }
}
