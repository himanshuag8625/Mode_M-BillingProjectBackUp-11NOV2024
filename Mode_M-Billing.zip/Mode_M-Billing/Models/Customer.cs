﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mode_M_Billing.Models
{
    public class Customer
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string CustomerName { get; set; }
        // Override ToString to display customer name in ComboBox
        public override string ToString()
        {
            return CustomerName;
        }
    }
}
