﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mode_M_Billing.Models
{
    public class LoginDetails
    {
        public string CustomerName { get; set; }
        public string FolderPath { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
