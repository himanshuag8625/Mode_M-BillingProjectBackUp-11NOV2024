﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mode_M_Billing.Models
{
    public class User
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
        public string Email { get; set; }
        public string WnsId { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string? FolderPath { get; set; }
        public List<string> Roles { get; set; } = new List<string>();
    }
}
