﻿using Mode_M_Billing.Views;
using System.Configuration;
using System.Data;
using System.Windows;

namespace Mode_M_Billing
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            // Open LoginWindow first
            var loginWindow = new LoginWindow();
            loginWindow.Show();

            // After login, you can open the main window and close the login window
            // For example, inside LoginWindow.xaml.cs, after successful login:
            // var mainWindow = new MainWindow();
            // mainWindow.Show();
            // this.Close(); // to close the login window
        }
    }

}
