﻿using System.Windows;
using Mode_M_Billing.Models; // Ensure User model namespace is included
using System.Windows.Controls;
using System.Windows.Media;

namespace Mode_M_Billing.Views
{
    public partial class UserEditWindow : Window
    {
        public User User { get; set; } // Public property to hold the User object

        // Constructor that takes a User object
        public UserEditWindow(User user)
        {
            InitializeComponent();
            User = user; // Set the User property

            // Populate the controls with the user data
            FirstName.Text = user.FirstName;
            LastName.Text = user.LastName;
            UserName.Text = user.UserName;
            Email.Text = user.Email;
            WnsId.Text = user.WnsId;
            IsActiveCheckBox.IsChecked = user.IsActive;
            IsDeletedCheckBox.IsChecked = user.IsDelete;
        }

        // Event handler for updating user details
        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            // Collect user data from input fields
            string firstName = FirstName.Text.Trim();
            string lastName = LastName.Text.Trim();
            string username = UserName.Text.Trim();
            string email = Email.Text.Trim();
            string wnsId = WnsId.Text.Trim();
            bool isActive = IsActiveCheckBox.IsChecked == true;
            bool isDeleted = IsDeletedCheckBox.IsChecked == true;

            // Update user object with new data
            User.FirstName = firstName;
            User.LastName = lastName;
            User.UserName = username;
            User.Email = email;
            User.WnsId = wnsId;
            User.IsActive = isActive;
            User.IsDelete = isDeleted;

            // Save the updated user to your user data store
            // Example: SaveUser(User);

            MessageBox.Show("User updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close(); // Close the window after updating
        }

        // Placeholder functionality for textboxes
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox)
            {
                if (textBox.Text == textBox.Name) // Assuming the placeholder text is the same as the name
                {
                    textBox.Text = string.Empty;
                    textBox.Foreground = new SolidColorBrush(Colors.Black); // Change text color to black
                }
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox)
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    textBox.Text = textBox.Name; // Restore placeholder
                    textBox.Foreground = new SolidColorBrush(Colors.Gray); // Change text color to gray
                }
            }
        }

        // Event handler to navigate to user list (if implemented)
        private void UserListTextBlock_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Navigate to the user list window
            // Example: new UserListWindow().Show();
            this.Close();
        }
    }
}
