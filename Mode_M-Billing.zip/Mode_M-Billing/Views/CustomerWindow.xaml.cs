﻿using Mode_M_Billing.Controller;
using Mode_M_Billing.Models;
using System;
using System.Windows;
using System.Windows.Controls;

namespace Mode_M_Billing.Views
{
    public partial class CustomerWindow : Window
    {
        private CustomerController _customerController;
        private SeleniumController _seleniumController;
        private ExcelController _excelController;

        public CustomerWindow()
        {
            InitializeComponent();
            _customerController = new CustomerController("CustomerData.json");
            _seleniumController = new SeleniumController();
            _excelController = new ExcelController();
            LoadCustomers();
        }

        //private void LoadCustomers()
        //{
        //    // Clear existing items
        //    CustomerNameComboBox.Items.Clear();

        //    // Load customers from the controller
        //    var customers = _customerController.GetCustomerViewModel().Customers;

        //    // Add the placeholder item first
        //    CustomerNameComboBox.Items.Add(new ComboBoxItem { Content = "--Select Customer--", IsEnabled = false });

        //    // Add the customer items to the ComboBox
        //    foreach (var customer in customers)
        //    {
        //        CustomerNameComboBox.Items.Add(customer);
        //    }

        //    // Set the selected value path and display member path
        //    CustomerNameComboBox.DisplayMemberPath = "CustomerName";
        //    CustomerNameComboBox.SelectedValuePath = "Id";

        //    // Set default selection to the placeholder (at index 0)
        //    CustomerNameComboBox.SelectedIndex = 0; // Select the placeholder initially
        //}

        private void LoadCustomers()
        {
            // Clear existing items
            CustomerNameComboBox.Items.Clear();

            // Load customers from the controller
            var customers = _customerController.GetCustomerViewModel().Customers;

            // Add the placeholder item first
            CustomerNameComboBox.Items.Add(new ComboBoxItem { Content = "--Select Customer--", IsEnabled = false });

            // Add the customer items to the ComboBox
            foreach (var customer in customers)
            {
                CustomerNameComboBox.Items.Add(customer);
            }

            // Set the selected index to the placeholder
            CustomerNameComboBox.SelectedIndex = 0; // Select the placeholder
        }


        private void CustomerNameComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Check if the selected index is greater than 0 (meaning a valid customer is selected)
            if (CustomerNameComboBox.SelectedIndex > 0)
            {
                // Get the selected customer
                var selectedCustomer = CustomerNameComboBox.SelectedItem as Customer;

                if (selectedCustomer != null)
                {
                    // Display the selected customer's name
                    Console.WriteLine($"Selected customer: {selectedCustomer.CustomerName}");
                }
            }
            else
            {
                // Display the placeholder message if no valid customer is selected
                Console.WriteLine("--Select Customer--");
            }
        }
        // Method to handle the Initiate Button Click
        private void InitiateButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedCustomer = CustomerNameComboBox.SelectedItem as Customer;
            var folderPath = FolderPathTextBox.Text.Trim();
            var username = UsernameTextBox.Text.Trim();
            var password = PasswordBox.Password.Trim();  // PasswordBox is used for password input

            if (selectedCustomer != null && !string.IsNullOrWhiteSpace(folderPath) &&
                !string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password))
            {
                // Create a LoginDetails object to store customer and login information
                var loginDetails = new LoginDetails
                {
                    CustomerName = selectedCustomer.CustomerName,
                    FolderPath = folderPath,
                    Username = username,
                    Password = password
                };

                // Save login details for future use
                _seleniumController.SaveLoginDetails(loginDetails);

                // Initiate the browser and navigate to the URL with login

                _seleniumController.UserLogin(loginDetails);

                // Check if PDF download is enabled
                if (PdfDownloadCheckBox.IsChecked == true)
                {
                    // Add logic for downloading PDF
                    _seleniumController.DownloadPdf(loginDetails);
                }

                _seleniumController.InitiateBrowser(loginDetails);

                _excelController.OpenExcel(loginDetails);
                if (PdfDownloadCheckBox.IsChecked == true)
                {
                    _excelController.ProcessExcelFile(loginDetails);
                }
                // Logic for initiating Excel if required
                // You can add logic here based on your needs, e.g.:
                // _seleniumController.InitiateExcelProcess(loginDetails);

                //MessageBox.Show("Browser Initiated with Customer and Login Information!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Please fill out all fields (Customer, Folder Path, Username, and Password).",
                                "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            var addCustomerWindow = new AddCustomerWindow();
            addCustomerWindow.Show();
            this.Close();
        }

        private void FolderPathTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            FolderPathLabel.Visibility = string.IsNullOrWhiteSpace(FolderPathTextBox.Text) ? Visibility.Visible : Visibility.Collapsed;
        }

        private void UsernameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UsernameLabel.Visibility = string.IsNullOrWhiteSpace(UsernameTextBox.Text) ? Visibility.Visible : Visibility.Collapsed;
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordLabel.Visibility = string.IsNullOrWhiteSpace(PasswordBox.Password) ? Visibility.Visible : Visibility.Collapsed;
        }
    }
}
