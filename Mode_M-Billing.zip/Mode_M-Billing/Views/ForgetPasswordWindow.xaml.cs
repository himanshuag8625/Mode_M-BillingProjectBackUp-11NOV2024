﻿using System.Windows;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Mode_M_Billing.Models;
using Newtonsoft.Json;
using System.IO;
using System.Windows.Media;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Windows.Controls;
using System.Windows.Input;

namespace Mode_M_Billing.Views
{
    public partial class ForgetPasswordWindow : Window
    {
        private string usersFile = "Userdata.json";  // Path to your JSON data file

        public ForgetPasswordWindow()
        {
            InitializeComponent();
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            string username = Username.Text.Trim(); // Trim to remove unnecessary whitespace
            string newPassword = NewPasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            // Check if passwords match
            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Encrypt new password
            string encryptedPassword = EncryptPassword(newPassword);
            string encryptedConfirmPassword = EncryptPassword(confirmPassword);

            // Load users and update password
            List<User> users = LoadUsers();

            // Find the user by username or email
            var user = users.FirstOrDefault(u => u.UserName.Equals(username, StringComparison.OrdinalIgnoreCase) ||
                                                 u.Email.Equals(username, StringComparison.OrdinalIgnoreCase) ||
                                                 u.WnsId.Equals(username, StringComparison.OrdinalIgnoreCase));

            if (user != null)
            {
                // Update the user's password
                user.Password = encryptedPassword;
                user.ConfirmPassword = encryptedConfirmPassword;
                SaveUsers(users);  // Save updated users list
                MessageBox.Show("Password reset successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close(); // Close the ForgetPasswordWindow after success
            }
            else
            {
                MessageBox.Show("User not found!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public static string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private List<User> LoadUsers()
        {
            // Load the users from the JSON file
            try
            {
                string json = File.ReadAllText(usersFile);
                return JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading users: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return new List<User>(); // Return an empty list if there's an error
            }
        }

        private void SaveUsers(List<User> users)
        {
            // Save the updated users to the JSON file
            try
            {
                string json = JsonConvert.SerializeObject(users, Formatting.Indented);
                File.WriteAllText(usersFile, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving users: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Event handler for username TextBox focus lost
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(Username.Text.Trim()))
            {
                Username.Text = "Username, Email, or WnsId"; // Set the placeholder text
                Username.Foreground = Brushes.Gray; // Change the text color to indicate it's a placeholder
            }
        }

        // Event handler for username TextBox focus gained
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Username.Text == "Username, Email, or WnsId")
            {
                Username.Text = string.Empty; // Clear the placeholder text
                Username.Foreground = Brushes.Black; // Change the text color to normal
            }
        }

        // Event handlers for new password placeholder
        private void NewPasswordPlaceholder_GotFocus(object sender, RoutedEventArgs e)
        {
            NewPasswordPlaceholder.Visibility = Visibility.Collapsed;
            NewPasswordBox.Visibility = Visibility.Visible;
            NewPasswordBox.Focus();
        }

        // Event handlers for confirm password placeholder
        private void ConfirmPasswordPlaceholder_GotFocus(object sender, RoutedEventArgs e)
        {
            ConfirmPasswordPlaceholder.Visibility = Visibility.Collapsed;
            ConfirmPasswordBox.Visibility = Visibility.Visible;
            ConfirmPasswordBox.Focus();
        }
        private void LoginTextBlock_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close(); // Close the current window or navigate away
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}
