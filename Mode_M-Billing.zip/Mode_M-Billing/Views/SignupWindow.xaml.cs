﻿using Mode_M_Billing.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Mode_M_Billing.Views
{
    /// <summary>
    /// Interaction logic for SignupWindow.xaml
    /// </summary>
    public partial class SignupWindow : Window
    {
        private readonly AccountController _accountController;
        public SignupWindow()
        {
            InitializeComponent();
            _accountController = new AccountController("Userdata.json");
        }
        // Placeholder behavior for TextBox
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox.Text == "First Name" || textBox.Text == "Last Name" || textBox.Text == "Username" || textBox.Text == "Email" || textBox.Text == "WnsId")
            {
                textBox.Text = "";
                textBox.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Foreground = System.Windows.Media.Brushes.Gray;
                textBox.Text = textBox.Name switch
                {
                    "FirstName" => "First Name",
                    "LastName" => "Last Name",
                    "UserName" => "Username",
                    "Email" => "Email",
                    "WnsId" => "WnsId",
                    _ => textBox.Text
                };
            }
        }

        // Placeholder behavior for PasswordBox
        private void PasswordPlaceholder_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordPlaceholder.Visibility = Visibility.Collapsed;
            PasswordBox.Visibility = Visibility.Visible;
            PasswordBox.Focus();
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                PasswordPlaceholder.Visibility = Visibility.Visible;
                PasswordBox.Visibility = Visibility.Collapsed;
            }
        }

        // Placeholder behavior for Confirm PasswordBox
        private void ConfirmPasswordPlaceholder_GotFocus(object sender, RoutedEventArgs e)
        {
            ConfirmPasswordPlaceholder.Visibility = Visibility.Collapsed;
            ConfirmPasswordBox.Visibility = Visibility.Visible;
            ConfirmPasswordBox.Focus();
        }

        private void ConfirmPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ConfirmPasswordBox.Password))
            {
                ConfirmPasswordPlaceholder.Visibility = Visibility.Visible;
                ConfirmPasswordBox.Visibility = Visibility.Collapsed;
            }
        }

        // Event handler for sign-up button
        //private void SignUpButton_Click(object sender, RoutedEventArgs e)
        //{
        //    string firstName = FirstName.Text;
        //    string lastName = LastName.Text;
        //    string userName = UserName.Text;
        //    string email = Email.Text;
        //    string wnsId = WnsId.Text;
        //    string password = PasswordBox.Password;
        //    string confirmPassword = ConfirmPasswordBox.Password;

        //    // Create an instance of AccountController
        //    AccountController accountController = new AccountController("Userdata.json");
        //    string signUpResult = accountController.RegisterUser(firstName, lastName, userName, email, wnsId, password, confirmPassword);

        //    if (signUpResult == "User registered successfully!")
        //    {
        //        MessageBox.Show("User registered successfully! Please log in.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

        //        // Open the LoginWindow and close the SignUpWindow
        //        var loginWindow = new LoginWindow();
        //        loginWindow.Show();
        //        this.Close(); // Close the SignUpWindow
        //    }
        //    else
        //    {
        //        MessageBox.Show(signUpResult, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        //    }
        //}

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            // Retrieve the values from the textboxes
            string firstName = FirstName.Text;
            string lastName = LastName.Text;
            string userName = UserName.Text;
            string email = Email.Text;
            string wnsId = WnsId.Text;
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            // Validation logic
            if (string.IsNullOrWhiteSpace(firstName) || firstName == "First Name")
            {
                MessageBox.Show("Please enter your first name.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(lastName) || lastName == "Last Name")
            {
                MessageBox.Show("Please enter your last name.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(userName) || userName == "Username")
            {
                MessageBox.Show("Please enter your username.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(email) || email == "Email")
            {
                MessageBox.Show("Please enter your email.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(wnsId) || wnsId == "WnsId")
            {
                MessageBox.Show("Please enter your WnsId.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter your password.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("Please confirm your password.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match. Please try again.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Create an instance of AccountController
            AccountController accountController = new AccountController("Userdata.json");
            string signUpResult = accountController.RegisterUser(firstName, lastName, userName, email, wnsId, password, confirmPassword);

            // Handle the result of the signup process
            if (signUpResult == "User registered successfully!")
            {
                MessageBox.Show("User registered successfully! Please log in.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                // Open the LoginWindow and close the SignUpWindow
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close(); // Close the SignUpWindow
            }
            else
            {
                MessageBox.Show(signUpResult, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LogInButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the SignUpWindow and close the LoginWindow
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close(); // Close the LoginWindow
        }

        private void UserListTextBlock_Click(object sender, MouseButtonEventArgs e)
        {
            UserListWindow userListWindow = new UserListWindow();
            userListWindow.Show();
            this.Close(); // Close the current window or navigate away
        }
    }
}
