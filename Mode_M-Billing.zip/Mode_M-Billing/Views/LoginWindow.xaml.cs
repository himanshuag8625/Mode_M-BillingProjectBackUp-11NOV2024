﻿using Mode_M_Billing.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Mode_M_Billing.Views
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        // Placeholder behavior for TextBox
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox.Text == "Username, Email, or WnsId")
            {
                textBox.Text = "";
                textBox.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Username, Email, or WnsId";
                textBox.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        // Placeholder behavior for PasswordBox
        private void PasswordPlaceholder_GotFocus(object sender, RoutedEventArgs e)
        {
            // Hide the placeholder TextBox and show the actual PasswordBox
            PasswordPlaceholder.Visibility = Visibility.Collapsed;
            PasswordBox.Visibility = Visibility.Visible;
            PasswordBox.Focus();
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the SignUpWindow and close the LoginWindow
            var signUpWindow = new SignupWindow();
            signUpWindow.Show();
            this.Close(); // Close the LoginWindow
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            // If the PasswordBox is empty, show the placeholder again
            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                PasswordPlaceholder.Visibility = Visibility.Visible;
                PasswordBox.Visibility = Visibility.Collapsed;
            }
        }

        // Event handler for login button
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string identifier = Identifier.Text;
            string password = PasswordBox.Password;

            // Use AccountController to check login credentials
            AccountController accountController = new AccountController("Userdata.json");
            string loginResult = accountController.LoginUser(identifier, password);

            // Handle login result
            if (loginResult == "Login successful!")
            {
                //MessageBox.Show("Login successful!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                // Proceed to the next window
                var customerWindow = new CustomerWindow();
                customerWindow.Show();
                this.Close(); // Close the LoginWindow
            }
            else if (loginResult == "User is not active.")
            {
                MessageBox.Show("Your account is not active. Please contact support.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (loginResult == "User has been deleted.")
            {
                MessageBox.Show("Your account has been deleted.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                MessageBox.Show("Invalid username, email, WnsId, or password!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ForgetPasswordButton_Click(object sender, RoutedEventArgs e)
        {
            // Open ForgetPasswordWindow
            ForgetPasswordWindow forgetPasswordWindow = new ForgetPasswordWindow();
            forgetPasswordWindow.Show();
        }
    }
}
