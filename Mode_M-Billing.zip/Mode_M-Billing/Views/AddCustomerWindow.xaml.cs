﻿using Mode_M_Billing.Controller;
using Mode_M_Billing.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Mode_M_Billing.Views
{
    /// <summary>
    /// Interaction logic for AddCustomerWindow.xaml
    /// </summary>
    public partial class AddCustomerWindow : Window
    {
        private CustomerController _customerController;
        public AddCustomerWindow()
        {
            InitializeComponent();
            _customerController = new CustomerController(); // Initialize your controller
        }

        private void AddCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            string customerName = CustomerNameTextBox.Text.Trim();
            //string folderPath = FolderPathTextBox.Text.Trim();

            if (string.IsNullOrEmpty(customerName))
            {
                MessageBox.Show("Please enter both Customer Name.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var newCustomer = new Customer
            {
                //Id = Guid.NewGuid().ToString(), // Generate a unique ID
                CustomerName = customerName,
                //FolderPath = folderPath
            };

            string result = _customerController.AddCustomer(newCustomer);
            MessageBox.Show(result, "Customer Management", MessageBoxButton.OK, MessageBoxImage.Information);

            // Optionally, clear the input fields after adding
            CustomerNameTextBox.Clear();
            var customerWindow = new CustomerWindow();
            customerWindow.Show();
            this.Close();
        }

        private void BackToCustomer_Click(object sender, RoutedEventArgs e)
        {
            // Open the SignUpWindow and close the LoginWindow
            var backToCustomer = new CustomerWindow();
            backToCustomer.Show();
            this.Close(); // Close the LoginWindow
        }

    }
}
