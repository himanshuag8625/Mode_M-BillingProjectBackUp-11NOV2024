﻿using Mode_M_Billing.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Mode_M_Billing.Views
{
    public partial class UserListWindow : Window
    {
        private List<User> users;
        private User selectedUser;

        public UserListWindow()
        {
            InitializeComponent();
            LoadUserData();
        }

        private void LoadUserData()
        {
            if (File.Exists("UserData.json"))
            {
                string json = File.ReadAllText("UserData.json");
                users = JsonSerializer.Deserialize<List<User>>(json) ?? new List<User>();
            }
            else
            {
                users = new List<User>();
            }
            UserDataGrid.ItemsSource = users;
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected user
            if (selectedUser != null)
            {
                UserEditWindow editWindow = new UserEditWindow(selectedUser); // Pass selected user to the edit window
                if (editWindow.ShowDialog() == true)
                {
                    // Update user in the list
                    var index = users.FindIndex(u => u.Id == selectedUser.Id);
                    if (index != -1)
                    {
                        users[index] = editWindow.User; // Get updated user from edit window
                    }
                    SaveUserData();
                    UserDataGrid.ItemsSource = null; // Reset the data grid
                    UserDataGrid.ItemsSource = users; // Rebind the updated list
                }
            }
            else
            {
                MessageBox.Show("Please select a user to edit.");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectedUser != null)
            {
                // Mark the user as deleted
                users.Remove(selectedUser);
                SaveUserData();
                UserDataGrid.ItemsSource = null; // Reset the data grid
                UserDataGrid.ItemsSource = users; // Rebind the updated list
            }
            else
            {
                MessageBox.Show("Please select a user to delete.");
            }
        }

        private void UserDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedUser = UserDataGrid.SelectedItem as User;
        }

        private void SaveUserData()
        {
            string json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText("UserData.json", json);
        }

        private void UserListTextBlock_Click(object sender, MouseButtonEventArgs e)
        {
            try
            {
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close(); // Close the current window or navigate away
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}
