﻿using Mode_M_Billing.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mode_M_Billing.ViewModels
{
    public class CustomerViewModel
    {
        public string SelectedCustomerName { get; set; }
        public List<Customer> Customers { get; set; }
        public string FolderPath { get; set; }
    }
}
